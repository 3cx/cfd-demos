using CallFlow.CFD;
using CallFlow;
using MimeKit;
using MySql.Data.MySqlClient;
using Npgsql;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Text;
using System.Threading.Tasks.Dataflow;
using System.Threading.Tasks;
using System.Threading;
using System;
using TCX.Configuration;

namespace OrderByPhone
{
    public class Main : ScriptBase<Main>, ICallflow, ICallflowProcessor
    {
        private bool executionStarted;
        private bool executionFinished;

        private BufferBlock<AbsEvent> eventBuffer;

        private int currentComponentIndex;
        private List<AbsComponent> mainFlowComponentList;
        private List<AbsComponent> disconnectFlowComponentList;
        private List<AbsComponent> errorFlowComponentList;
        private List<AbsComponent> currentFlowComponentList;

        private LogFormatter logFormatter;
        private TimerManager timerManager;
        private Dictionary<string, Variable> variableMap;
        private TempWavFileManager tempWavFileManager;
        private PromptQueue promptQueue;
        private OnlineServices onlineServices;

        private void DisconnectCallAndExitCallflow()
        {
            logFormatter.Trace("Callflow finished, disconnecting call...");
            MyCall.Terminate();
        }

        private async Task ExecuteErrorFlow()
        {
            if (currentFlowComponentList == errorFlowComponentList)
            {
                logFormatter.Trace("Error during error handler flow, exiting callflow...");
                DisconnectCallAndExitCallflow();
            }
            else
            {
                currentFlowComponentList = errorFlowComponentList;
                currentComponentIndex = 0;
                if (errorFlowComponentList.Count > 0)
                {
                    logFormatter.Trace("Start executing error handler flow...");
                    await ProcessStart();
                }
                else
                {
                    logFormatter.Trace("Error handler flow is empty...");
                    DisconnectCallAndExitCallflow();
                }
            }
        }

        private EventResults CheckEventResult(EventResults eventResult)
        {
            if (eventResult == EventResults.MoveToNextComponent && ++currentComponentIndex == currentFlowComponentList.Count)
            {
                DisconnectCallAndExitCallflow();
                return EventResults.Exit;
            }
            else if (eventResult == EventResults.Exit)
                DisconnectCallAndExitCallflow();

            return eventResult;
        }

        private void InitializeVariables(string callID)
        {
            // Call variables
            variableMap["session.ani"] = new Variable(MyCall.Caller.CallerID);
            variableMap["session.callid"] = new Variable(callID);
            variableMap["session.dnis"] = new Variable(MyCall.DN.Number);
            variableMap["session.did"] = new Variable(MyCall.Caller.CalledNumber);
            variableMap["session.audioFolder"] = new Variable(Path.Combine(RecordingManager.Instance.AudioFolder, promptQueue.ProjectAudioFolder));
            variableMap["session.transferingExtension"] = new Variable(MyCall["onbehlfof"] ?? string.Empty);

            // Standard variables
            variableMap["RecordResult.NothingRecorded"] = new Variable(RecordComponent.RecordResults.NothingRecorded);
            variableMap["RecordResult.StopDigit"] = new Variable(RecordComponent.RecordResults.StopDigit);
            variableMap["RecordResult.Completed"] = new Variable(RecordComponent.RecordResults.Completed);
            variableMap["MenuResult.Timeout"] = new Variable(MenuComponent.MenuResults.Timeout);
            variableMap["MenuResult.InvalidOption"] = new Variable(MenuComponent.MenuResults.InvalidOption);
            variableMap["MenuResult.ValidOption"] = new Variable(MenuComponent.MenuResults.ValidOption);
            variableMap["UserInputResult.Timeout"] = new Variable(UserInputComponent.UserInputResults.Timeout);
            variableMap["UserInputResult.InvalidDigits"] = new Variable(UserInputComponent.UserInputResults.InvalidDigits);
            variableMap["UserInputResult.ValidDigits"] = new Variable(UserInputComponent.UserInputResults.ValidDigits);
            variableMap["VoiceInputResult.Timeout"] = new Variable(VoiceInputComponent.VoiceInputResults.Timeout);
            variableMap["VoiceInputResult.InvalidInput"] = new Variable(VoiceInputComponent.VoiceInputResults.InvalidInput);
            variableMap["VoiceInputResult.ValidInput"] = new Variable(VoiceInputComponent.VoiceInputResults.ValidInput);

            // User variables
            variableMap["project$.OperatorExtension"] = new Variable(100);
            variableMap["project$.DatabaseServer"] = new Variable("ENTER_DATABASE_SERVER");
            variableMap["project$.DatabasePort"] = new Variable(3306);
            variableMap["project$.DatabaseName"] = new Variable("ENTER_DATABASE_NAME");
            variableMap["project$.DatabaseUsername"] = new Variable("ENTER_USER_NAME");
            variableMap["project$.DatabasePassword"] = new Variable("ENTER_PASSWORD");
            variableMap["RecordResult.NothingRecorded"] = new Variable(RecordComponent.RecordResults.NothingRecorded);
            variableMap["RecordResult.StopDigit"] = new Variable(RecordComponent.RecordResults.StopDigit);
            variableMap["RecordResult.Completed"] = new Variable(RecordComponent.RecordResults.Completed);
            variableMap["MenuResult.Timeout"] = new Variable(MenuComponent.MenuResults.Timeout);
            variableMap["MenuResult.InvalidOption"] = new Variable(MenuComponent.MenuResults.InvalidOption);
            variableMap["MenuResult.ValidOption"] = new Variable(MenuComponent.MenuResults.ValidOption);
            variableMap["UserInputResult.Timeout"] = new Variable(UserInputComponent.UserInputResults.Timeout);
            variableMap["UserInputResult.InvalidDigits"] = new Variable(UserInputComponent.UserInputResults.InvalidDigits);
            variableMap["UserInputResult.ValidDigits"] = new Variable(UserInputComponent.UserInputResults.ValidDigits);
            variableMap["VoiceInputResult.Timeout"] = new Variable(VoiceInputComponent.VoiceInputResults.Timeout);
            variableMap["VoiceInputResult.InvalidInput"] = new Variable(VoiceInputComponent.VoiceInputResults.InvalidInput);
            variableMap["VoiceInputResult.ValidInput"] = new Variable(VoiceInputComponent.VoiceInputResults.ValidInput);
            
        }

        private void InitializeComponents(ICallflow callflow, ICall myCall, string logHeader)
        {
            {
            PromptPlaybackComponent Welcome = new PromptPlaybackComponent("Welcome", callflow, myCall, logHeader);
            Welcome.AllowDtmfInput = false;
            Welcome.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Welcome to Super Easy Teleshopping! Please wait to confirm your account."); }));
            mainFlowComponentList.Add(Welcome);
            ContactLookup SearchContactInSalesforce = new ContactLookup(onlineServices, "SearchContactInSalesforce", callflow, myCall, logHeader);
            mainFlowComponentList.Add(SearchContactInSalesforce);
            ConditionalComponent CheckContactFound = new ConditionalComponent("CheckContactFound", callflow, myCall, logHeader);
            mainFlowComponentList.Add(CheckContactFound);
            CheckContactFound.ConditionList.Add(() => { return Convert.ToBoolean(SearchContactInSalesforce.ContactFound); });
            CheckContactFound.ContainerList.Add(new SequenceContainerComponent("CheckContactFound_0", callflow, myCall, logHeader));
            MenuComponent MainMenu = new MenuComponent("MainMenu", callflow, myCall, logHeader);
            MainMenu.AllowDtmfInput = true;
            MainMenu.MaxRetryCount = 2;
            MainMenu.Timeout = 5000;
            MainMenu.ValidOptionList.AddRange(new char[] { '0', '1', '2' });
            MainMenu.InitialPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("Hello "),Convert.ToString(SearchContactInSalesforce.ContactName),Convert.ToString("! To place an order please press 1. To check your order status press 2. Or, to contact an available sales operator, press 0."))); }));
            MainMenu.SubsequentPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("To place an order please press 1. To check your order status press 2. Or, to contact an available sales operator, press 0."); }));
            MainMenu.InvalidDigitPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Sorry, the selected option is invalid."); }));
            MainMenu.TimeoutPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Sorry, we didn't receive any digit."); }));
            CheckContactFound.ContainerList[0].ComponentList.Add(MainMenu);
            ConditionalComponent MainMenu_Conditional = new ConditionalComponent("MainMenu_Conditional", callflow, myCall, logHeader);
            CheckContactFound.ContainerList[0].ComponentList.Add(MainMenu_Conditional);
            MainMenu_Conditional.ConditionList.Add(() => { return MainMenu.Result == MenuComponent.MenuResults.ValidOption && MainMenu.SelectedOption == '0'; });
            MainMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("MainMenu_Conditional_Option0", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayTransferingToSales = new PromptPlaybackComponent("PlayTransferingToSales", callflow, myCall, logHeader);
            PlayTransferingToSales.AllowDtmfInput = true;
            PlayTransferingToSales.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We're transferring you to a sales operator."); }));
            MainMenu_Conditional.ContainerList[0].ComponentList.Add(PlayTransferingToSales);
            TransferComponent TransferToSalesOperator = new TransferComponent("TransferToSalesOperator", callflow, myCall, logHeader);
            TransferToSalesOperator.DestinationHandler = () => { return Convert.ToString(variableMap["project$.OperatorExtension"].Value); };
            TransferToSalesOperator.DelayMilliseconds = 0;
            MainMenu_Conditional.ContainerList[0].ComponentList.Add(TransferToSalesOperator);
            MainMenu_Conditional.ConditionList.Add(() => { return MainMenu.Result == MenuComponent.MenuResults.ValidOption && MainMenu.SelectedOption == '1'; });
            MainMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("MainMenu_Conditional_Option1", callflow, myCall, logHeader));
            AuthenticateContact DoAuthentication = new AuthenticateContact(onlineServices, "DoAuthentication", callflow, myCall, logHeader);
            DoAuthentication.ContactIDSetter = () => { return SearchContactInSalesforce.ContactID; };
            MainMenu_Conditional.ContainerList[1].ComponentList.Add(DoAuthentication);
            OrderMultipleItems StartOrdering = new OrderMultipleItems(onlineServices, "StartOrdering", callflow, myCall, logHeader);
            StartOrdering.ContactIDSetter = () => { return SearchContactInSalesforce.ContactID; };
            StartOrdering.ContactEmailSetter = () => { return SearchContactInSalesforce.ContactEmail; };
            StartOrdering.ContactNameSetter = () => { return SearchContactInSalesforce.ContactName; };
            MainMenu_Conditional.ContainerList[1].ComponentList.Add(StartOrdering);
            MainMenu_Conditional.ConditionList.Add(() => { return MainMenu.Result == MenuComponent.MenuResults.ValidOption && MainMenu.SelectedOption == '2'; });
            MainMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("MainMenu_Conditional_Option2", callflow, myCall, logHeader));
            CheckOrderStatus CheckOrderStatus = new CheckOrderStatus(onlineServices, "CheckOrderStatus", callflow, myCall, logHeader);
            MainMenu_Conditional.ContainerList[2].ComponentList.Add(CheckOrderStatus);
            MainMenu_Conditional.ConditionList.Add(() => { return MainMenu.Result == MenuComponent.MenuResults.InvalidOption || MainMenu.Result == MenuComponent.MenuResults.Timeout; });
            MainMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("MainMenu_Conditional_TimeoutOrInvalidOption", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayTransferingToSalesOnTimeout = new PromptPlaybackComponent("PlayTransferingToSalesOnTimeout", callflow, myCall, logHeader);
            PlayTransferingToSalesOnTimeout.AllowDtmfInput = true;
            PlayTransferingToSalesOnTimeout.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We're transfering you to a sales operator."); }));
            MainMenu_Conditional.ContainerList[3].ComponentList.Add(PlayTransferingToSalesOnTimeout);
            TransferComponent TransferToSalesOperatorOnTimeout = new TransferComponent("TransferToSalesOperatorOnTimeout", callflow, myCall, logHeader);
            TransferToSalesOperatorOnTimeout.DestinationHandler = () => { return Convert.ToString(variableMap["project$.OperatorExtension"].Value); };
            TransferToSalesOperatorOnTimeout.DelayMilliseconds = 0;
            MainMenu_Conditional.ContainerList[3].ComponentList.Add(TransferToSalesOperatorOnTimeout);
            CheckContactFound.ConditionList.Add(() => { return Convert.ToBoolean(true); });
            CheckContactFound.ContainerList.Add(new SequenceContainerComponent("CheckContactFound_1", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayContactNotFound = new PromptPlaybackComponent("PlayContactNotFound", callflow, myCall, logHeader);
            PlayContactNotFound.AllowDtmfInput = true;
            PlayContactNotFound.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Sorry, we cannot locate your phone number in our records. We're transferring you to an operator so you can set up your account."); }));
            CheckContactFound.ContainerList[1].ComponentList.Add(PlayContactNotFound);
            TransferComponent TransferToOperator = new TransferComponent("TransferToOperator", callflow, myCall, logHeader);
            TransferToOperator.DestinationHandler = () => { return Convert.ToString(variableMap["project$.OperatorExtension"].Value); };
            TransferToOperator.DelayMilliseconds = 0;
            CheckContactFound.ContainerList[1].ComponentList.Add(TransferToOperator);
            }
            {
            PromptPlaybackComponent PlayError = new PromptPlaybackComponent("PlayError", callflow, myCall, logHeader);
            PlayError.AllowDtmfInput = true;
            PlayError.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Sorry, an error has occurred. We're transfering you to an operator for further assistance."); }));
            errorFlowComponentList.Add(PlayError);
            TransferComponent TransferOnError = new TransferComponent("TransferOnError", callflow, myCall, logHeader);
            TransferOnError.DestinationHandler = () => { return Convert.ToString(variableMap["project$.OperatorExtension"].Value); };
            TransferOnError.DelayMilliseconds = 0;
            errorFlowComponentList.Add(TransferOnError);
            }
            {
            }
            

            // Add a final DisconnectCall component to the main and error handler flows, in order to complete pending prompt playbacks...
            DisconnectCallComponent mainAutoAddedFinalDisconnectCall = new DisconnectCallComponent("mainAutoAddedFinalDisconnectCall", callflow, myCall, logHeader);
            DisconnectCallComponent errorHandlerAutoAddedFinalDisconnectCall = new DisconnectCallComponent("errorHandlerAutoAddedFinalDisconnectCall", callflow, myCall, logHeader);
            mainFlowComponentList.Add(mainAutoAddedFinalDisconnectCall);
            errorFlowComponentList.Add(errorHandlerAutoAddedFinalDisconnectCall);
        }

        private bool IsServerOfficeHourActive(ICall myCall)
        {
            DateTime nowDt = DateTime.Now;
            Tenant tenant = myCall.PS.GetTenant();
            if (tenant == null || tenant.IsHoliday(new DateTimeOffset(nowDt)))
                return false;

            string overrideOfficeTime = tenant.GetPropertyValue("OVERRIDEOFFICETIME");
            if (!String.IsNullOrEmpty(overrideOfficeTime))
            {
                if (overrideOfficeTime == "1") // Forced to in office hours
                    return true;
                else if (overrideOfficeTime == "2") // Forced to out of office hours
                    return false;
            }

            Schedule officeHours = tenant.Hours;
            Nullable<bool> result = officeHours.IsActiveTime(nowDt);
            return result.GetValueOrDefault(false);
        }

        public Main()
        {
            this.executionStarted = false;
            this.executionFinished = false;

            this.eventBuffer = new BufferBlock<AbsEvent>();

            this.currentComponentIndex = 0;
            this.mainFlowComponentList = new List<AbsComponent>();
            this.disconnectFlowComponentList = new List<AbsComponent>();
            this.errorFlowComponentList = new List<AbsComponent>();
            this.currentFlowComponentList = mainFlowComponentList;

            this.timerManager = new TimerManager();
            this.timerManager.OnTimeout += (state) => eventBuffer.Post(new TimeoutEvent(state));
            this.variableMap = new Dictionary<string, Variable>();

            AbsTextToSpeechEngine textToSpeechEngine = new AmazonPollyTextToSpeechEngine(new AmazonPollySettings("ENTER_CLIENT_ID", "ENTER_CLIENT_SECRET", "us-east-2", new List<string>() {  }));
            AbsSpeechToTextEngine speechToTextEngine = null;
            this.onlineServices = new OnlineServices(textToSpeechEngine, speechToTextEngine);
        }

        public override void Start()
        {
            MyCall.SetBackgroundAudio(false, new string[] { });

            string callID = MyCall?.Caller["chid"] ?? "Unknown";
            string logHeader = $"OrderByPhone - CallID {callID}";
            this.logFormatter = new LogFormatter(MyCall, logHeader, "Callflow");
            this.promptQueue = new PromptQueue(this, MyCall, "OrderByPhone", logHeader);
            this.tempWavFileManager = new TempWavFileManager(logFormatter);
            this.timerManager.CallStarted();

            InitializeComponents(this, MyCall, logHeader);
            InitializeVariables(callID);
            
            MyCall.OnTerminated += () => eventBuffer.Post(new CallTerminatedEvent());
            MyCall.OnDTMFInput += x => eventBuffer.Post(new DTMFReceivedEvent(x));

            logFormatter.Trace("Start executing main flow...");
            eventBuffer.Post(new StartEvent());
            Task.Run(() => EventProcessingLoop());

            
        }
        
        public void PostStartEvent()
        {
            eventBuffer.Post(new StartEvent());
        }

        public void PostDTMFReceivedEvent(char digit)
        {
            eventBuffer.Post(new DTMFReceivedEvent(digit));
        }

        public void PostPromptPlayedEvent()
        {
            eventBuffer.Post(new PromptPlayedEvent());
        }

        public void PostTransferFailedEvent()
        {
            eventBuffer.Post(new TransferFailedEvent());
        }

        public void PostMakeCallResultEvent(bool result)
        {
            eventBuffer.Post(new MakeCallResultEvent(result));
        }

        public void PostCallTerminatedEvent()
        {
            eventBuffer.Post(new CallTerminatedEvent());
        }

        public void PostTimeoutEvent(object state)
        {
            eventBuffer.Post(new TimeoutEvent(state));
        }

        private async Task EventProcessingLoop()
        {
            executionStarted = true;
            while (!executionFinished)
            {
                AbsEvent evt = await eventBuffer.ReceiveAsync();
                await evt?.ProcessEvent(this);
            }
        }
        
        public async Task ProcessStart()
        {
            try
            {
                EventResults eventResult;
                do
                {
                    AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                    logFormatter.Trace("Start executing component '" + currentComponent.Name + "'");
                    eventResult = await currentComponent.Start(timerManager, variableMap, tempWavFileManager, promptQueue);
                }
                while (CheckEventResult(eventResult) == EventResults.MoveToNextComponent);
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessDTMFReceived(char digit)
        {
            try
            {
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnDTMFReceived for component '" + currentComponent.Name + "' - Digit: '" + digit + "'");
                EventResults eventResult = await currentComponent.OnDTMFReceived(timerManager, variableMap, tempWavFileManager, promptQueue, digit);
                if (CheckEventResult(eventResult) == EventResults.MoveToNextComponent)
                    await ProcessStart();
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessPromptPlayed()
        {
            try
            {
                promptQueue.NotifyPlayFinished();
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnPromptPlayed for component '" + currentComponent.Name + "'");
                EventResults eventResult = await currentComponent.OnPromptPlayed(timerManager, variableMap, tempWavFileManager, promptQueue);
                if (CheckEventResult(eventResult) == EventResults.MoveToNextComponent)
                    await ProcessStart();
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessTransferFailed()
        {
            try
            {
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnTransferFailed for component '" + currentComponent.Name + "'");
                EventResults eventResult = await currentComponent.OnTransferFailed(timerManager, variableMap, tempWavFileManager, promptQueue);
                if (CheckEventResult(eventResult) == EventResults.MoveToNextComponent)
                    await ProcessStart();
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessMakeCallResult(bool result)
        {
            try
            {
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnMakeCallResult for component '" + currentComponent.Name + "' - Result: '" + result + "'");
                EventResults eventResult = await currentComponent.OnMakeCallResult(timerManager, variableMap, tempWavFileManager, promptQueue, result);
                if (CheckEventResult(eventResult) == EventResults.MoveToNextComponent)
                    await ProcessStart();
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessCallTerminated()
        {
            try
            {
                if (executionStarted)
                {
                    // First notify the current component
                    AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                    logFormatter.Trace("OnCallTerminated for component '" + currentComponent.Name + "'");
                    await currentComponent.OnCallTerminated(timerManager, variableMap, tempWavFileManager, promptQueue);

                    // Next, execute disconnect flow
                    currentFlowComponentList = disconnectFlowComponentList;
                    logFormatter.Trace("Start executing disconnect handler flow...");
                    foreach (AbsComponent component in disconnectFlowComponentList)
                    {
                        logFormatter.Trace("Start executing component '" + component.Name + "'");
                        await component.Start(timerManager, variableMap, tempWavFileManager, promptQueue);
                    }
                }
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
            finally
            {
                // Finally, delete temporary files
                tempWavFileManager.DeleteFilesAndFolders();
                executionFinished = true;
            }
        }

        public async Task ProcessTimeout(object state)
        {
            try
            {
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnTimeout for component '" + currentComponent.Name + "'");
                EventResults eventResult = await currentComponent.OnTimeout(timerManager, variableMap, tempWavFileManager, promptQueue, state);
                if (CheckEventResult(eventResult) == EventResults.MoveToNextComponent)
                    await ProcessStart();
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }


                // ------------------------------------------------------------------------------------------------------------
        // User Defined component
        // ------------------------------------------------------------------------------------------------------------
        public class AuthenticateContact : AbsUserComponent
        {
            private OnlineServices onlineServices;

            private ObjectExpressionHandler _ContactIDHandler = null;
            

            protected override void InitializeVariables()
            {
                componentVariableMap["callflow$.ContactID"] = new Variable("");
                
            }

            protected override void InitializeComponents()
            {
                Dictionary<string, Variable> variableMap = componentVariableMap;
                {
            AuthenticationLoopComponent AskForPin = new AuthenticationLoopComponent("AskForPin", callflow, myCall, logHeader);
            AskForPin.Condition = () => { return Convert.ToBoolean(CFDFunctions.AND(Convert.ToBoolean(CFDFunctions.LESS_THAN((IComparable)AskForPin.LoopCounter,(IComparable)4)),Convert.ToBoolean(CFDFunctions.NOT(Convert.ToBoolean(variableMap["AskForPin.Validated"].Value))))); };
            AskForPin.Container = new SequenceContainerComponent("AskForPin_Container", callflow, myCall, logHeader);
            mainFlowComponentList.Add(AskForPin);
            UserInputComponent AskForPinRequestId = new UserInputComponent("AskForPinRequestId", callflow, myCall, logHeader);
            AskForPinRequestId.AllowDtmfInput = true;
            AskForPinRequestId.MaxRetryCount = 2;
            AskForPinRequestId.FirstDigitTimeout = 5000;
            AskForPinRequestId.InterDigitTimeout = 3000;
            AskForPinRequestId.FinalDigitTimeout = 2000;
            AskForPinRequestId.MinDigits = 6;
            AskForPinRequestId.MaxDigits = 6;
            AskForPinRequestId.ValidDigitList.AddRange(new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' });
            AskForPinRequestId.InitialPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Please enter your 6-digit PIN number to authenticate your account."); }));
            AskForPinRequestId.SubsequentPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Please enter your 6-digit PIN number to authenticate your account."); }));
            AskForPinRequestId.InvalidDigitPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Your input is invalid."); }));
            AskForPinRequestId.TimeoutPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We didn't receive any digit."); }));
            AskForPin.Container.ComponentList.Add(AskForPinRequestId);
            AskForPin.IdHandler = () => { return AskForPinRequestId.Buffer; };
            ConditionalComponent AskForPinRequestId_Conditional = new ConditionalComponent("AskForPinRequestId_Conditional", callflow, myCall, logHeader);
            AskForPin.Container.ComponentList.Add(AskForPinRequestId_Conditional);
            AskForPinRequestId_Conditional.ConditionList.Add(() => { return AskForPinRequestId.Result == UserInputComponent.UserInputResults.ValidDigits; });
            AskForPinRequestId_Conditional.ContainerList.Add(new SequenceContainerComponent("AskForPinRequestId_Conditional_ValidInput", callflow, myCall, logHeader));
            MySqlDatabaseAccessComponent ValidatePIN = new MySqlDatabaseAccessComponent("ValidatePIN", callflow, myCall, logHeader);
            ValidatePIN.ServerHandler = () => { return Convert.ToString(variableMap["project$.DatabaseServer"].Value); };
            ValidatePIN.PortHandler = () => { return Convert.ToInt32(variableMap["project$.DatabasePort"].Value); };
            ValidatePIN.DatabaseHandler = () => { return Convert.ToString(variableMap["project$.DatabaseName"].Value); };
            ValidatePIN.UserNameHandler = () => { return Convert.ToString(variableMap["project$.DatabaseUsername"].Value); };
            ValidatePIN.PasswordHandler = () => { return Convert.ToString(variableMap["project$.DatabasePassword"].Value); };
            ValidatePIN.SqlStatementHandler = () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("SELECT count(*) FROM customers WHERE id='"),Convert.ToString(variableMap["callflow$.ContactID"].Value),Convert.ToString("' AND pin='"),Convert.ToString(AskForPin.ID),Convert.ToString("'"))); };
            ValidatePIN.UseConnectionString = false;
            ValidatePIN.StatementType = DatabaseAccessComponent.StatementTypes.Scalar;
            ValidatePIN.Timeout = 30000;
            AskForPinRequestId_Conditional.ContainerList[0].ComponentList.Add(ValidatePIN);
            ConditionalComponent CheckValidPIN = new ConditionalComponent("CheckValidPIN", callflow, myCall, logHeader);
            AskForPinRequestId_Conditional.ContainerList[0].ComponentList.Add(CheckValidPIN);
            CheckValidPIN.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.GREAT_THAN_OR_EQUAL((IComparable)ValidatePIN.ScalarResult,(IComparable)CFDFunctions.TO_LONG(1))); });
            CheckValidPIN.ContainerList.Add(new SequenceContainerComponent("CheckValidPIN_0", callflow, myCall, logHeader));
            VariableAssignmentComponent SetValidated = new VariableAssignmentComponent("SetValidated", callflow, myCall, logHeader);
            SetValidated.VariableName = "AskForPin.Validated";
            SetValidated.VariableValueHandler = () => { return true; };
            CheckValidPIN.ContainerList[0].ComponentList.Add(SetValidated);
            PromptPlaybackComponent PlaySuccess = new PromptPlaybackComponent("PlaySuccess", callflow, myCall, logHeader);
            PlaySuccess.AllowDtmfInput = true;
            PlaySuccess.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Your account is confirmed."); }));
            CheckValidPIN.ContainerList[0].ComponentList.Add(PlaySuccess);
            CheckValidPIN.ConditionList.Add(() => { return Convert.ToBoolean(true); });
            CheckValidPIN.ContainerList.Add(new SequenceContainerComponent("CheckValidPIN_1", callflow, myCall, logHeader));
            MenuComponent InvalidPinMenu = new MenuComponent("InvalidPinMenu", callflow, myCall, logHeader);
            InvalidPinMenu.AllowDtmfInput = true;
            InvalidPinMenu.MaxRetryCount = 2;
            InvalidPinMenu.Timeout = 5000;
            InvalidPinMenu.ValidOptionList.AddRange(new char[] { '0', '1', '2' });
            InvalidPinMenu.InitialPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We could not confirm your account. To retry press 1. To cancel press 2. Or, to contact the operator press 0."); }));
            InvalidPinMenu.SubsequentPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("To retry press 1. To cancel press 2. Or, to contact the operator press 0."); }));
            InvalidPinMenu.InvalidDigitPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("The selected option is invalid."); }));
            InvalidPinMenu.TimeoutPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We didn't receive any digit."); }));
            CheckValidPIN.ContainerList[1].ComponentList.Add(InvalidPinMenu);
            ConditionalComponent InvalidPinMenu_Conditional = new ConditionalComponent("InvalidPinMenu_Conditional", callflow, myCall, logHeader);
            CheckValidPIN.ContainerList[1].ComponentList.Add(InvalidPinMenu_Conditional);
            InvalidPinMenu_Conditional.ConditionList.Add(() => { return InvalidPinMenu.Result == MenuComponent.MenuResults.ValidOption && InvalidPinMenu.SelectedOption == '0'; });
            InvalidPinMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("InvalidPinMenu_Conditional_Option0", callflow, myCall, logHeader));
            TransferComponent TransferToOperatorOnInvalidPIN = new TransferComponent("TransferToOperatorOnInvalidPIN", callflow, myCall, logHeader);
            TransferToOperatorOnInvalidPIN.DestinationHandler = () => { return Convert.ToString(variableMap["project$.OperatorExtension"].Value); };
            TransferToOperatorOnInvalidPIN.DelayMilliseconds = 0;
            InvalidPinMenu_Conditional.ContainerList[0].ComponentList.Add(TransferToOperatorOnInvalidPIN);
            InvalidPinMenu_Conditional.ConditionList.Add(() => { return InvalidPinMenu.Result == MenuComponent.MenuResults.ValidOption && InvalidPinMenu.SelectedOption == '1'; });
            InvalidPinMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("InvalidPinMenu_Conditional_Option1", callflow, myCall, logHeader));
            VariableAssignmentComponent SetNotValidated = new VariableAssignmentComponent("SetNotValidated", callflow, myCall, logHeader);
            SetNotValidated.VariableName = "AskForPin.Validated";
            SetNotValidated.VariableValueHandler = () => { return false; };
            InvalidPinMenu_Conditional.ContainerList[1].ComponentList.Add(SetNotValidated);
            InvalidPinMenu_Conditional.ConditionList.Add(() => { return InvalidPinMenu.Result == MenuComponent.MenuResults.ValidOption && InvalidPinMenu.SelectedOption == '2'; });
            InvalidPinMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("InvalidPinMenu_Conditional_Option2", callflow, myCall, logHeader));
            DisconnectCallComponent DropCall = new DisconnectCallComponent("DropCall", callflow, myCall, logHeader);
            InvalidPinMenu_Conditional.ContainerList[2].ComponentList.Add(DropCall);
            InvalidPinMenu_Conditional.ConditionList.Add(() => { return InvalidPinMenu.Result == MenuComponent.MenuResults.InvalidOption || InvalidPinMenu.Result == MenuComponent.MenuResults.Timeout; });
            InvalidPinMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("InvalidPinMenu_Conditional_TimeoutOrInvalidOption", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayTransferMessage = new PromptPlaybackComponent("PlayTransferMessage", callflow, myCall, logHeader);
            PlayTransferMessage.AllowDtmfInput = true;
            PlayTransferMessage.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We're transfering you to an operator so you can make your order."); }));
            InvalidPinMenu_Conditional.ContainerList[3].ComponentList.Add(PlayTransferMessage);
            TransferComponent TransferToOperatorOnTimeout = new TransferComponent("TransferToOperatorOnTimeout", callflow, myCall, logHeader);
            TransferToOperatorOnTimeout.DestinationHandler = () => { return Convert.ToString(variableMap["project$.OperatorExtension"].Value); };
            TransferToOperatorOnTimeout.DelayMilliseconds = 0;
            InvalidPinMenu_Conditional.ContainerList[3].ComponentList.Add(TransferToOperatorOnTimeout);
            ConditionalComponent AskForPin_InvalidInputConditional = new ConditionalComponent("AskForPin_InvalidInputConditional", callflow, myCall, logHeader);
            AskForPin.Container.ComponentList.Add(AskForPin_InvalidInputConditional);
            AskForPin_InvalidInputConditional.ConditionList.Add(() => { return AskForPinRequestId.Result == UserInputComponent.UserInputResults.InvalidDigits || AskForPinRequestId.Result == UserInputComponent.UserInputResults.Timeout; });
            AskForPin_InvalidInputConditional.ContainerList.Add(new SequenceContainerComponent("AskForPin_InvalidInputConditional", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayPinNotEntered = new PromptPlaybackComponent("PlayPinNotEntered", callflow, myCall, logHeader);
            PlayPinNotEntered.AllowDtmfInput = true;
            PlayPinNotEntered.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Sorry, we couldn't validate your PIN number. We're transfering you to an operator so you can make your order."); }));
            AskForPin_InvalidInputConditional.ContainerList[0].ComponentList.Add(PlayPinNotEntered);
            TransferComponent TransferToOperator = new TransferComponent("TransferToOperator", callflow, myCall, logHeader);
            TransferToOperator.DestinationHandler = () => { return Convert.ToString(variableMap["project$.OperatorExtension"].Value); };
            TransferToOperator.DelayMilliseconds = 0;
            AskForPin_InvalidInputConditional.ContainerList[0].ComponentList.Add(TransferToOperator);
            }
            {
            }
            {
            }
            
            }
            
            public AuthenticateContact(OnlineServices onlineServices, string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
                this.onlineServices = onlineServices;
            }

            protected override void GetVariableValues()
            {
                if (_ContactIDHandler != null) componentVariableMap["callflow$.ContactID"].Set(_ContactIDHandler());
                
            }
            
            public ObjectExpressionHandler ContactIDSetter { set { _ContactIDHandler = value; } }
            public object ContactID { get { return componentVariableMap["callflow$.ContactID"].Value; } }
            

            private bool IsServerOfficeHourActive(ICall myCall)
            {
                DateTime nowDt = DateTime.Now;
                Tenant tenant = myCall.PS.GetTenant();
                if (tenant == null || tenant.IsHoliday(new DateTimeOffset(nowDt)))
                    return false;

                string overrideOfficeTime = tenant.GetPropertyValue("OVERRIDEOFFICETIME");
                if (!String.IsNullOrEmpty(overrideOfficeTime))
                {
                    if (overrideOfficeTime == "1") // Forced to in office hours
                        return true;
                    else if (overrideOfficeTime == "2") // Forced to out of office hours
                        return false;
                }

                Schedule officeHours = tenant.Hours;
                Nullable<bool> result = officeHours.IsActiveTime(nowDt);
                return result.GetValueOrDefault(false);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        // User Defined component
        // ------------------------------------------------------------------------------------------------------------
        public class CheckOrderStatus : AbsUserComponent
        {
            private OnlineServices onlineServices;

            private ObjectExpressionHandler _TryNumberHandler = null;
            

            protected override void InitializeVariables()
            {
                componentVariableMap["callflow$.TryNumber"] = new Variable(0);
                
            }

            protected override void InitializeComponents()
            {
                Dictionary<string, Variable> variableMap = componentVariableMap;
                {
            LoopComponent AskReferenceNumberLoop = new LoopComponent("AskReferenceNumberLoop", callflow, myCall, logHeader);
            AskReferenceNumberLoop.Condition = () => { return Convert.ToBoolean(CFDFunctions.LESS_THAN((IComparable)variableMap["callflow$.TryNumber"].Value,(IComparable)3)); };
            AskReferenceNumberLoop.Container = new SequenceContainerComponent("AskReferenceNumberLoop_Container", callflow, myCall, logHeader);
            mainFlowComponentList.Add(AskReferenceNumberLoop);
            UserInputComponent AskReferenceNumber = new UserInputComponent("AskReferenceNumber", callflow, myCall, logHeader);
            AskReferenceNumber.AllowDtmfInput = true;
            AskReferenceNumber.MaxRetryCount = 2;
            AskReferenceNumber.FirstDigitTimeout = 5000;
            AskReferenceNumber.InterDigitTimeout = 3000;
            AskReferenceNumber.FinalDigitTimeout = 2000;
            AskReferenceNumber.MinDigits = 6;
            AskReferenceNumber.MaxDigits = 6;
            AskReferenceNumber.ValidDigitList.AddRange(new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' });
            AskReferenceNumber.StopDigitList.AddRange(new char[] { '#' });
            AskReferenceNumber.InitialPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Please enter your 6-digit order reference number to retrieve the order status."); }));
            AskReferenceNumber.SubsequentPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Please enter your 6-digit order reference number to retrieve the order status."); }));
            AskReferenceNumber.InvalidDigitPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Your input is not valid."); }));
            AskReferenceNumber.TimeoutPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We didn't receive any digit."); }));
            AskReferenceNumberLoop.Container.ComponentList.Add(AskReferenceNumber);
            ConditionalComponent AskReferenceNumber_Conditional = new ConditionalComponent("AskReferenceNumber_Conditional", callflow, myCall, logHeader);
            AskReferenceNumberLoop.Container.ComponentList.Add(AskReferenceNumber_Conditional);
            AskReferenceNumber_Conditional.ConditionList.Add(() => { return AskReferenceNumber.Result == UserInputComponent.UserInputResults.ValidDigits; });
            AskReferenceNumber_Conditional.ContainerList.Add(new SequenceContainerComponent("AskReferenceNumber_Conditional_ValidInput", callflow, myCall, logHeader));
            MySqlDatabaseAccessComponent GetOrderStatus = new MySqlDatabaseAccessComponent("GetOrderStatus", callflow, myCall, logHeader);
            GetOrderStatus.ServerHandler = () => { return Convert.ToString(variableMap["project$.DatabaseServer"].Value); };
            GetOrderStatus.PortHandler = () => { return Convert.ToInt32(variableMap["project$.DatabasePort"].Value); };
            GetOrderStatus.DatabaseHandler = () => { return Convert.ToString(variableMap["project$.DatabaseName"].Value); };
            GetOrderStatus.UserNameHandler = () => { return Convert.ToString(variableMap["project$.DatabaseUsername"].Value); };
            GetOrderStatus.PasswordHandler = () => { return Convert.ToString(variableMap["project$.DatabasePassword"].Value); };
            GetOrderStatus.SqlStatementHandler = () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("SELECT status FROM orders WHERE id ="),Convert.ToString(AskReferenceNumber.Buffer))); };
            GetOrderStatus.UseConnectionString = false;
            GetOrderStatus.StatementType = DatabaseAccessComponent.StatementTypes.Scalar;
            GetOrderStatus.Timeout = 30000;
            AskReferenceNumber_Conditional.ContainerList[0].ComponentList.Add(GetOrderStatus);
            ConditionalComponent CheckValidOrder = new ConditionalComponent("CheckValidOrder", callflow, myCall, logHeader);
            AskReferenceNumber_Conditional.ContainerList[0].ComponentList.Add(CheckValidOrder);
            CheckValidOrder.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.GREAT_THAN((IComparable)CFDFunctions.LEN(Convert.ToString(GetOrderStatus.ScalarResult)),(IComparable)0)); });
            CheckValidOrder.ContainerList.Add(new SequenceContainerComponent("CheckValidOrder_0", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayOrderStatus = new PromptPlaybackComponent("PlayOrderStatus", callflow, myCall, logHeader);
            PlayOrderStatus.AllowDtmfInput = true;
            PlayOrderStatus.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("The status of your order is: "),Convert.ToString(GetOrderStatus.ScalarResult),Convert.ToString(". Thanks for contacting Super Easy Teleshopping! Have a nice day!"))); }));
            CheckValidOrder.ContainerList[0].ComponentList.Add(PlayOrderStatus);
            DisconnectCallComponent DropCall = new DisconnectCallComponent("DropCall", callflow, myCall, logHeader);
            CheckValidOrder.ContainerList[0].ComponentList.Add(DropCall);
            CheckValidOrder.ConditionList.Add(() => { return Convert.ToBoolean(true); });
            CheckValidOrder.ContainerList.Add(new SequenceContainerComponent("CheckValidOrder_1", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayInvalidOrder = new PromptPlaybackComponent("PlayInvalidOrder", callflow, myCall, logHeader);
            PlayInvalidOrder.AllowDtmfInput = true;
            PlayInvalidOrder.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We couldn't find this order number. Please re-enter."); }));
            CheckValidOrder.ContainerList[1].ComponentList.Add(PlayInvalidOrder);
            IncrementVariableComponent IncrementTryNumber = new IncrementVariableComponent("IncrementTryNumber", callflow, myCall, logHeader);
            IncrementTryNumber.VariableName = "callflow$.TryNumber";
            CheckValidOrder.ContainerList[1].ComponentList.Add(IncrementTryNumber);
            AskReferenceNumber_Conditional.ConditionList.Add(() => { return AskReferenceNumber.Result == UserInputComponent.UserInputResults.InvalidDigits || AskReferenceNumber.Result == UserInputComponent.UserInputResults.Timeout; });
            AskReferenceNumber_Conditional.ContainerList.Add(new SequenceContainerComponent("AskReferenceNumber_Conditional_InvalidInput", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayNoOrderReference = new PromptPlaybackComponent("PlayNoOrderReference", callflow, myCall, logHeader);
            PlayNoOrderReference.AllowDtmfInput = true;
            PlayNoOrderReference.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Sorry, we couldn't get your order reference number. We're transfering you to an operator."); }));
            AskReferenceNumber_Conditional.ContainerList[1].ComponentList.Add(PlayNoOrderReference);
            TransferComponent TransferToOperator = new TransferComponent("TransferToOperator", callflow, myCall, logHeader);
            TransferToOperator.DestinationHandler = () => { return Convert.ToString(variableMap["project$.OperatorExtension"].Value); };
            TransferToOperator.DelayMilliseconds = 0;
            AskReferenceNumber_Conditional.ContainerList[1].ComponentList.Add(TransferToOperator);
            PromptPlaybackComponent PlayTransferToOperator = new PromptPlaybackComponent("PlayTransferToOperator", callflow, myCall, logHeader);
            PlayTransferToOperator.AllowDtmfInput = true;
            PlayTransferToOperator.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We're transfering you to an operator."); }));
            mainFlowComponentList.Add(PlayTransferToOperator);
            TransferComponent TransferToOperatorOnInvalidOrder = new TransferComponent("TransferToOperatorOnInvalidOrder", callflow, myCall, logHeader);
            TransferToOperatorOnInvalidOrder.DestinationHandler = () => { return Convert.ToString(variableMap["project$.OperatorExtension"].Value); };
            TransferToOperatorOnInvalidOrder.DelayMilliseconds = 0;
            mainFlowComponentList.Add(TransferToOperatorOnInvalidOrder);
            }
            {
            }
            {
            }
            
            }
            
            public CheckOrderStatus(OnlineServices onlineServices, string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
                this.onlineServices = onlineServices;
            }

            protected override void GetVariableValues()
            {
                if (_TryNumberHandler != null) componentVariableMap["callflow$.TryNumber"].Set(_TryNumberHandler());
                
            }
            
            public ObjectExpressionHandler TryNumberSetter { set { _TryNumberHandler = value; } }
            public object TryNumber { get { return componentVariableMap["callflow$.TryNumber"].Value; } }
            

            private bool IsServerOfficeHourActive(ICall myCall)
            {
                DateTime nowDt = DateTime.Now;
                Tenant tenant = myCall.PS.GetTenant();
                if (tenant == null || tenant.IsHoliday(new DateTimeOffset(nowDt)))
                    return false;

                string overrideOfficeTime = tenant.GetPropertyValue("OVERRIDEOFFICETIME");
                if (!String.IsNullOrEmpty(overrideOfficeTime))
                {
                    if (overrideOfficeTime == "1") // Forced to in office hours
                        return true;
                    else if (overrideOfficeTime == "2") // Forced to out of office hours
                        return false;
                }

                Schedule officeHours = tenant.Hours;
                Nullable<bool> result = officeHours.IsActiveTime(nowDt);
                return result.GetValueOrDefault(false);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        // User Defined component
        // ------------------------------------------------------------------------------------------------------------
        public class ContactLookup : AbsUserComponent
        {
            private OnlineServices onlineServices;

            private ObjectExpressionHandler _ContactFoundHandler = null;
            private ObjectExpressionHandler _ContactIDHandler = null;
            private ObjectExpressionHandler _ContactNameHandler = null;
            private ObjectExpressionHandler _ContactEmailHandler = null;
            private ObjectExpressionHandler _FirstNameHandler = null;
            private ObjectExpressionHandler _LastNameHandler = null;
            

            protected override void InitializeVariables()
            {
                componentVariableMap["callflow$.ContactFound"] = new Variable(false);
                componentVariableMap["callflow$.ContactID"] = new Variable("");
                componentVariableMap["callflow$.ContactName"] = new Variable("");
                componentVariableMap["callflow$.ContactEmail"] = new Variable("");
                componentVariableMap["callflow$.FirstName"] = new Variable("");
                componentVariableMap["callflow$.LastName"] = new Variable("");
                
            }

            protected override void InitializeComponents()
            {
                Dictionary<string, Variable> variableMap = componentVariableMap;
                {
            CRMLookupComponent SearchContacts = new CRMLookupComponent("SearchContacts", callflow, myCall, logHeader);
            SearchContacts.EntityType = CRMLookupComponent.EntityTypes.Contacts;
            SearchContacts.QueryType = CRMLookupComponent.QueryTypes.LookupNumber;
            SearchContacts.DataHandler = () => { return Convert.ToString(variableMap["session.ani"].Value); };
            mainFlowComponentList.Add(SearchContacts);
            TextAnalyzerComponent SearchContacts_ResponseAnalyzer = new TextAnalyzerComponent("SearchContacts", callflow, myCall, logHeader);
            SearchContacts_ResponseAnalyzer.TextType = TextAnalyzerComponent.TextTypes.Detect;
            SearchContacts_ResponseAnalyzer.TextHandler = () => { return Convert.ToString(SearchContacts.Result); };
            SearchContacts_ResponseAnalyzer.Mappings.Add("Id", "callflow$.ContactID");
            SearchContacts_ResponseAnalyzer.Mappings.Add("FirstName", "callflow$.FirstName");
            SearchContacts_ResponseAnalyzer.Mappings.Add("LastName", "callflow$.LastName");
            SearchContacts_ResponseAnalyzer.Mappings.Add("Email", "callflow$.ContactEmail");
            mainFlowComponentList.Add(SearchContacts_ResponseAnalyzer);
            ConditionalComponent CheckContactFound = new ConditionalComponent("CheckContactFound", callflow, myCall, logHeader);
            mainFlowComponentList.Add(CheckContactFound);
            CheckContactFound.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.GREAT_THAN((IComparable)CFDFunctions.LEN(Convert.ToString(variableMap["callflow$.ContactID"].Value)),(IComparable)0)); });
            CheckContactFound.ContainerList.Add(new SequenceContainerComponent("CheckContactFound_0", callflow, myCall, logHeader));
            VariableAssignmentComponent SetContactName = new VariableAssignmentComponent("SetContactName", callflow, myCall, logHeader);
            SetContactName.VariableName = "callflow$.ContactName";
            SetContactName.VariableValueHandler = () => { return CFDFunctions.CONCATENATE(Convert.ToString(variableMap["callflow$.FirstName"].Value),Convert.ToString(" "),Convert.ToString(variableMap["callflow$.LastName"].Value)); };
            CheckContactFound.ContainerList[0].ComponentList.Add(SetContactName);
            VariableAssignmentComponent SetContactFound = new VariableAssignmentComponent("SetContactFound", callflow, myCall, logHeader);
            SetContactFound.VariableName = "callflow$.ContactFound";
            SetContactFound.VariableValueHandler = () => { return true; };
            CheckContactFound.ContainerList[0].ComponentList.Add(SetContactFound);
            CheckContactFound.ConditionList.Add(() => { return Convert.ToBoolean(true); });
            CheckContactFound.ContainerList.Add(new SequenceContainerComponent("CheckContactFound_1", callflow, myCall, logHeader));
            VariableAssignmentComponent SetAccountNotFound = new VariableAssignmentComponent("SetAccountNotFound", callflow, myCall, logHeader);
            SetAccountNotFound.VariableName = "callflow$.ContactFound";
            SetAccountNotFound.VariableValueHandler = () => { return false; };
            CheckContactFound.ContainerList[1].ComponentList.Add(SetAccountNotFound);
            }
            {
            }
            {
            }
            
            }
            
            public ContactLookup(OnlineServices onlineServices, string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
                this.onlineServices = onlineServices;
            }

            protected override void GetVariableValues()
            {
                if (_ContactFoundHandler != null) componentVariableMap["callflow$.ContactFound"].Set(_ContactFoundHandler());
                if (_ContactIDHandler != null) componentVariableMap["callflow$.ContactID"].Set(_ContactIDHandler());
                if (_ContactNameHandler != null) componentVariableMap["callflow$.ContactName"].Set(_ContactNameHandler());
                if (_ContactEmailHandler != null) componentVariableMap["callflow$.ContactEmail"].Set(_ContactEmailHandler());
                if (_FirstNameHandler != null) componentVariableMap["callflow$.FirstName"].Set(_FirstNameHandler());
                if (_LastNameHandler != null) componentVariableMap["callflow$.LastName"].Set(_LastNameHandler());
                
            }
            
            public ObjectExpressionHandler ContactFoundSetter { set { _ContactFoundHandler = value; } }
            public object ContactFound { get { return componentVariableMap["callflow$.ContactFound"].Value; } }
            public ObjectExpressionHandler ContactIDSetter { set { _ContactIDHandler = value; } }
            public object ContactID { get { return componentVariableMap["callflow$.ContactID"].Value; } }
            public ObjectExpressionHandler ContactNameSetter { set { _ContactNameHandler = value; } }
            public object ContactName { get { return componentVariableMap["callflow$.ContactName"].Value; } }
            public ObjectExpressionHandler ContactEmailSetter { set { _ContactEmailHandler = value; } }
            public object ContactEmail { get { return componentVariableMap["callflow$.ContactEmail"].Value; } }
            public ObjectExpressionHandler FirstNameSetter { set { _FirstNameHandler = value; } }
            public object FirstName { get { return componentVariableMap["callflow$.FirstName"].Value; } }
            public ObjectExpressionHandler LastNameSetter { set { _LastNameHandler = value; } }
            public object LastName { get { return componentVariableMap["callflow$.LastName"].Value; } }
            

            private bool IsServerOfficeHourActive(ICall myCall)
            {
                DateTime nowDt = DateTime.Now;
                Tenant tenant = myCall.PS.GetTenant();
                if (tenant == null || tenant.IsHoliday(new DateTimeOffset(nowDt)))
                    return false;

                string overrideOfficeTime = tenant.GetPropertyValue("OVERRIDEOFFICETIME");
                if (!String.IsNullOrEmpty(overrideOfficeTime))
                {
                    if (overrideOfficeTime == "1") // Forced to in office hours
                        return true;
                    else if (overrideOfficeTime == "2") // Forced to out of office hours
                        return false;
                }

                Schedule officeHours = tenant.Hours;
                Nullable<bool> result = officeHours.IsActiveTime(nowDt);
                return result.GetValueOrDefault(false);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        // User Defined component
        // ------------------------------------------------------------------------------------------------------------
        public class ItemAddNotification : AbsUserComponent
        {
            private OnlineServices onlineServices;

            private ObjectExpressionHandler _ItemIDHandler = null;
            private ObjectExpressionHandler _ContactIDHandler = null;
            

            protected override void InitializeVariables()
            {
                componentVariableMap["callflow$.ItemID"] = new Variable("");
                componentVariableMap["callflow$.ContactID"] = new Variable("");
                
            }

            protected override void InitializeComponents()
            {
                Dictionary<string, Variable> variableMap = componentVariableMap;
                {
            MenuComponent GetNotifiedMenu = new MenuComponent("GetNotifiedMenu", callflow, myCall, logHeader);
            GetNotifiedMenu.AllowDtmfInput = true;
            GetNotifiedMenu.MaxRetryCount = 2;
            GetNotifiedMenu.Timeout = 5000;
            GetNotifiedMenu.ValidOptionList.AddRange(new char[] { '1', '2' });
            GetNotifiedMenu.InitialPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Insufficient quantity for this item. To get notified when this item is available press 1, to cancel press 2."); }));
            GetNotifiedMenu.SubsequentPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("To get notified when this item is available press 1, to cancel press 2."); }));
            GetNotifiedMenu.InvalidDigitPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Sorry, the selected option is invalid."); }));
            GetNotifiedMenu.TimeoutPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Sorry, we didn't receive any digit."); }));
            mainFlowComponentList.Add(GetNotifiedMenu);
            ConditionalComponent GetNotifiedMenu_Conditional = new ConditionalComponent("GetNotifiedMenu_Conditional", callflow, myCall, logHeader);
            mainFlowComponentList.Add(GetNotifiedMenu_Conditional);
            GetNotifiedMenu_Conditional.ConditionList.Add(() => { return GetNotifiedMenu.Result == MenuComponent.MenuResults.ValidOption && GetNotifiedMenu.SelectedOption == '1'; });
            GetNotifiedMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("GetNotifiedMenu_Conditional_Option1", callflow, myCall, logHeader));
            MySqlDatabaseAccessComponent AddNotification = new MySqlDatabaseAccessComponent("AddNotification", callflow, myCall, logHeader);
            AddNotification.ServerHandler = () => { return Convert.ToString(variableMap["project$.DatabaseServer"].Value); };
            AddNotification.PortHandler = () => { return Convert.ToInt32(variableMap["project$.DatabasePort"].Value); };
            AddNotification.DatabaseHandler = () => { return Convert.ToString(variableMap["project$.DatabaseName"].Value); };
            AddNotification.UserNameHandler = () => { return Convert.ToString(variableMap["project$.DatabaseUsername"].Value); };
            AddNotification.PasswordHandler = () => { return Convert.ToString(variableMap["project$.DatabasePassword"].Value); };
            AddNotification.SqlStatementHandler = () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("INSERT INTO notifications (contactid, itemid) VALUES ('"),Convert.ToString(variableMap["callflow$.ContactID"].Value),Convert.ToString("',"),Convert.ToString(variableMap["callflow$.ItemID"].Value),Convert.ToString(")"))); };
            AddNotification.UseConnectionString = false;
            AddNotification.StatementType = DatabaseAccessComponent.StatementTypes.NonQuery;
            AddNotification.Timeout = 30000;
            GetNotifiedMenu_Conditional.ContainerList[0].ComponentList.Add(AddNotification);
            PromptPlaybackComponent PlayNotificationRegistered = new PromptPlaybackComponent("PlayNotificationRegistered", callflow, myCall, logHeader);
            PlayNotificationRegistered.AllowDtmfInput = true;
            PlayNotificationRegistered.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We will notify you via email or SMS when this item is available."); }));
            GetNotifiedMenu_Conditional.ContainerList[0].ComponentList.Add(PlayNotificationRegistered);
            GetNotifiedMenu_Conditional.ConditionList.Add(() => { return GetNotifiedMenu.Result == MenuComponent.MenuResults.ValidOption && GetNotifiedMenu.SelectedOption == '2'; });
            GetNotifiedMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("GetNotifiedMenu_Conditional_Option2", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayNoNotification = new PromptPlaybackComponent("PlayNoNotification", callflow, myCall, logHeader);
            PlayNoNotification.AllowDtmfInput = true;
            PlayNoNotification.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("You will not be notified when this item has stock."); }));
            GetNotifiedMenu_Conditional.ContainerList[1].ComponentList.Add(PlayNoNotification);
            GetNotifiedMenu_Conditional.ConditionList.Add(() => { return GetNotifiedMenu.Result == MenuComponent.MenuResults.InvalidOption || GetNotifiedMenu.Result == MenuComponent.MenuResults.Timeout; });
            GetNotifiedMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("GetNotifiedMenu_Conditional_TimeoutOrInvalidOption", callflow, myCall, logHeader));
            PromptPlaybackComponent NoNotification = new PromptPlaybackComponent("NoNotification", callflow, myCall, logHeader);
            NoNotification.AllowDtmfInput = true;
            NoNotification.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("You will not be notified when this item has stock."); }));
            GetNotifiedMenu_Conditional.ContainerList[2].ComponentList.Add(NoNotification);
            }
            {
            }
            {
            }
            
            }
            
            public ItemAddNotification(OnlineServices onlineServices, string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
                this.onlineServices = onlineServices;
            }

            protected override void GetVariableValues()
            {
                if (_ItemIDHandler != null) componentVariableMap["callflow$.ItemID"].Set(_ItemIDHandler());
                if (_ContactIDHandler != null) componentVariableMap["callflow$.ContactID"].Set(_ContactIDHandler());
                
            }
            
            public ObjectExpressionHandler ItemIDSetter { set { _ItemIDHandler = value; } }
            public object ItemID { get { return componentVariableMap["callflow$.ItemID"].Value; } }
            public ObjectExpressionHandler ContactIDSetter { set { _ContactIDHandler = value; } }
            public object ContactID { get { return componentVariableMap["callflow$.ContactID"].Value; } }
            

            private bool IsServerOfficeHourActive(ICall myCall)
            {
                DateTime nowDt = DateTime.Now;
                Tenant tenant = myCall.PS.GetTenant();
                if (tenant == null || tenant.IsHoliday(new DateTimeOffset(nowDt)))
                    return false;

                string overrideOfficeTime = tenant.GetPropertyValue("OVERRIDEOFFICETIME");
                if (!String.IsNullOrEmpty(overrideOfficeTime))
                {
                    if (overrideOfficeTime == "1") // Forced to in office hours
                        return true;
                    else if (overrideOfficeTime == "2") // Forced to out of office hours
                        return false;
                }

                Schedule officeHours = tenant.Hours;
                Nullable<bool> result = officeHours.IsActiveTime(nowDt);
                return result.GetValueOrDefault(false);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        // User Defined component
        // ------------------------------------------------------------------------------------------------------------
        public class ItemChangeQuantity : AbsUserComponent
        {
            private OnlineServices onlineServices;

            private ObjectExpressionHandler _MaxQuantityHandler = null;
            private ObjectExpressionHandler _SelectedQuantityHandler = null;
            private ObjectExpressionHandler _HasToAskQuantityHandler = null;
            

            protected override void InitializeVariables()
            {
                componentVariableMap["callflow$.MaxQuantity"] = new Variable("");
                componentVariableMap["callflow$.SelectedQuantity"] = new Variable(1);
                componentVariableMap["callflow$.HasToAskQuantity"] = new Variable(true);
                
            }

            protected override void InitializeComponents()
            {
                Dictionary<string, Variable> variableMap = componentVariableMap;
                {
            LoopComponent AskQuantityLoop = new LoopComponent("AskQuantityLoop", callflow, myCall, logHeader);
            AskQuantityLoop.Condition = () => { return Convert.ToBoolean(variableMap["callflow$.HasToAskQuantity"].Value); };
            AskQuantityLoop.Container = new SequenceContainerComponent("AskQuantityLoop_Container", callflow, myCall, logHeader);
            mainFlowComponentList.Add(AskQuantityLoop);
            UserInputComponent AskQuantity = new UserInputComponent("AskQuantity", callflow, myCall, logHeader);
            AskQuantity.AllowDtmfInput = true;
            AskQuantity.MaxRetryCount = 2;
            AskQuantity.FirstDigitTimeout = 5000;
            AskQuantity.InterDigitTimeout = 3000;
            AskQuantity.FinalDigitTimeout = 2000;
            AskQuantity.MinDigits = 1;
            AskQuantity.MaxDigits = 3;
            AskQuantity.ValidDigitList.AddRange(new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' });
            AskQuantity.StopDigitList.AddRange(new char[] { '#' });
            AskQuantity.InitialPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("Enter up to "),Convert.ToString(variableMap["callflow$.MaxQuantity"].Value),Convert.ToString(" items to order or 0 to cancel ordering this item."))); }));
            AskQuantity.SubsequentPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("Enter up to "),Convert.ToString(variableMap["callflow$.MaxQuantity"].Value),Convert.ToString(" items to order or 0 to cancel ordering this item."))); }));
            AskQuantity.InvalidDigitPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Your input is invalid."); }));
            AskQuantity.TimeoutPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We didn't receive any digit."); }));
            AskQuantityLoop.Container.ComponentList.Add(AskQuantity);
            ConditionalComponent AskQuantity_Conditional = new ConditionalComponent("AskQuantity_Conditional", callflow, myCall, logHeader);
            AskQuantityLoop.Container.ComponentList.Add(AskQuantity_Conditional);
            AskQuantity_Conditional.ConditionList.Add(() => { return AskQuantity.Result == UserInputComponent.UserInputResults.ValidDigits; });
            AskQuantity_Conditional.ContainerList.Add(new SequenceContainerComponent("AskQuantity_Conditional_ValidInput", callflow, myCall, logHeader));
            VariableAssignmentComponent SetQuantity = new VariableAssignmentComponent("SetQuantity", callflow, myCall, logHeader);
            SetQuantity.VariableName = "callflow$.SelectedQuantity";
            SetQuantity.VariableValueHandler = () => { return CFDFunctions.TO_INTEGER(AskQuantity.Buffer); };
            AskQuantity_Conditional.ContainerList[0].ComponentList.Add(SetQuantity);
            ConditionalComponent CheckStock = new ConditionalComponent("CheckStock", callflow, myCall, logHeader);
            AskQuantity_Conditional.ContainerList[0].ComponentList.Add(CheckStock);
            CheckStock.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.LESS_THAN_OR_EQUAL((IComparable)variableMap["callflow$.SelectedQuantity"].Value,(IComparable)variableMap["callflow$.MaxQuantity"].Value)); });
            CheckStock.ContainerList.Add(new SequenceContainerComponent("CheckStock_0", callflow, myCall, logHeader));
            VariableAssignmentComponent ExitLoop = new VariableAssignmentComponent("ExitLoop", callflow, myCall, logHeader);
            ExitLoop.VariableName = "callflow$.HasToAskQuantity";
            ExitLoop.VariableValueHandler = () => { return false; };
            CheckStock.ContainerList[0].ComponentList.Add(ExitLoop);
            CheckStock.ConditionList.Add(() => { return Convert.ToBoolean(true); });
            CheckStock.ContainerList.Add(new SequenceContainerComponent("CheckStock_1", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayNotEnoughStock = new PromptPlaybackComponent("PlayNotEnoughStock", callflow, myCall, logHeader);
            PlayNotEnoughStock.AllowDtmfInput = true;
            PlayNotEnoughStock.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("Only "),Convert.ToString(variableMap["callflow$.MaxQuantity"].Value),Convert.ToString(" items in stock. Please enter a lower quantity or 0 to cancel."))); }));
            CheckStock.ContainerList[1].ComponentList.Add(PlayNotEnoughStock);
            AskQuantity_Conditional.ConditionList.Add(() => { return AskQuantity.Result == UserInputComponent.UserInputResults.InvalidDigits || AskQuantity.Result == UserInputComponent.UserInputResults.Timeout; });
            AskQuantity_Conditional.ContainerList.Add(new SequenceContainerComponent("AskQuantity_Conditional_InvalidInput", callflow, myCall, logHeader));
            VariableAssignmentComponent SetZero = new VariableAssignmentComponent("SetZero", callflow, myCall, logHeader);
            SetZero.VariableName = "callflow$.SelectedQuantity";
            SetZero.VariableValueHandler = () => { return 0; };
            AskQuantity_Conditional.ContainerList[1].ComponentList.Add(SetZero);
            }
            {
            }
            {
            }
            
            }
            
            public ItemChangeQuantity(OnlineServices onlineServices, string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
                this.onlineServices = onlineServices;
            }

            protected override void GetVariableValues()
            {
                if (_MaxQuantityHandler != null) componentVariableMap["callflow$.MaxQuantity"].Set(_MaxQuantityHandler());
                if (_SelectedQuantityHandler != null) componentVariableMap["callflow$.SelectedQuantity"].Set(_SelectedQuantityHandler());
                if (_HasToAskQuantityHandler != null) componentVariableMap["callflow$.HasToAskQuantity"].Set(_HasToAskQuantityHandler());
                
            }
            
            public ObjectExpressionHandler MaxQuantitySetter { set { _MaxQuantityHandler = value; } }
            public object MaxQuantity { get { return componentVariableMap["callflow$.MaxQuantity"].Value; } }
            public ObjectExpressionHandler SelectedQuantitySetter { set { _SelectedQuantityHandler = value; } }
            public object SelectedQuantity { get { return componentVariableMap["callflow$.SelectedQuantity"].Value; } }
            public ObjectExpressionHandler HasToAskQuantitySetter { set { _HasToAskQuantityHandler = value; } }
            public object HasToAskQuantity { get { return componentVariableMap["callflow$.HasToAskQuantity"].Value; } }
            

            private bool IsServerOfficeHourActive(ICall myCall)
            {
                DateTime nowDt = DateTime.Now;
                Tenant tenant = myCall.PS.GetTenant();
                if (tenant == null || tenant.IsHoliday(new DateTimeOffset(nowDt)))
                    return false;

                string overrideOfficeTime = tenant.GetPropertyValue("OVERRIDEOFFICETIME");
                if (!String.IsNullOrEmpty(overrideOfficeTime))
                {
                    if (overrideOfficeTime == "1") // Forced to in office hours
                        return true;
                    else if (overrideOfficeTime == "2") // Forced to out of office hours
                        return false;
                }

                Schedule officeHours = tenant.Hours;
                Nullable<bool> result = officeHours.IsActiveTime(nowDt);
                return result.GetValueOrDefault(false);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        // User Defined component
        // ------------------------------------------------------------------------------------------------------------
        public class OrderMultipleItems : AbsUserComponent
        {
            private OnlineServices onlineServices;

            private ObjectExpressionHandler _ContactIDHandler = null;
            private ObjectExpressionHandler _ContactNameHandler = null;
            private ObjectExpressionHandler _ContactEmailHandler = null;
            private ObjectExpressionHandler _ContinueOrderingHandler = null;
            private ObjectExpressionHandler _OrderIDHandler = null;
            private ObjectExpressionHandler _ItemIndexHandler = null;
            private ObjectExpressionHandler _TotalAmountHandler = null;
            

            protected override void InitializeVariables()
            {
                componentVariableMap["callflow$.ContactID"] = new Variable("");
                componentVariableMap["callflow$.ContactName"] = new Variable("");
                componentVariableMap["callflow$.ContactEmail"] = new Variable("");
                componentVariableMap["callflow$.ContinueOrdering"] = new Variable(true);
                componentVariableMap["callflow$.OrderID"] = new Variable("");
                componentVariableMap["callflow$.ItemIndex"] = new Variable(0);
                componentVariableMap["callflow$.TotalAmount"] = new Variable(0);
                
            }

            protected override void InitializeComponents()
            {
                Dictionary<string, Variable> variableMap = componentVariableMap;
                {
            PromptPlaybackComponent PlayReady = new PromptPlaybackComponent("PlayReady", callflow, myCall, logHeader);
            PlayReady.AllowDtmfInput = true;
            PlayReady.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We're ready to take your order!"); }));
            mainFlowComponentList.Add(PlayReady);
            MySqlDatabaseAccessComponent CreateOrder = new MySqlDatabaseAccessComponent("CreateOrder", callflow, myCall, logHeader);
            CreateOrder.ServerHandler = () => { return Convert.ToString(variableMap["project$.DatabaseServer"].Value); };
            CreateOrder.PortHandler = () => { return Convert.ToInt32(variableMap["project$.DatabasePort"].Value); };
            CreateOrder.DatabaseHandler = () => { return Convert.ToString(variableMap["project$.DatabaseName"].Value); };
            CreateOrder.UserNameHandler = () => { return Convert.ToString(variableMap["project$.DatabaseUsername"].Value); };
            CreateOrder.PasswordHandler = () => { return Convert.ToString(variableMap["project$.DatabasePassword"].Value); };
            CreateOrder.SqlStatementHandler = () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("INSERT INTO orders (customerid, status) VALUES ('"),Convert.ToString(variableMap["callflow$.ContactID"].Value),Convert.ToString("','Customer Ordering'); SELECT LAST_INSERT_ID();"))); };
            CreateOrder.UseConnectionString = false;
            CreateOrder.StatementType = DatabaseAccessComponent.StatementTypes.Scalar;
            CreateOrder.Timeout = 30000;
            mainFlowComponentList.Add(CreateOrder);
            VariableAssignmentComponent SetOrderID = new VariableAssignmentComponent("SetOrderID", callflow, myCall, logHeader);
            SetOrderID.VariableName = "callflow$.OrderID";
            SetOrderID.VariableValueHandler = () => { return CreateOrder.ScalarResult; };
            mainFlowComponentList.Add(SetOrderID);
            LoopComponent OrderingLoop = new LoopComponent("OrderingLoop", callflow, myCall, logHeader);
            OrderingLoop.Condition = () => { return Convert.ToBoolean(variableMap["callflow$.ContinueOrdering"].Value); };
            OrderingLoop.Container = new SequenceContainerComponent("OrderingLoop_Container", callflow, myCall, logHeader);
            mainFlowComponentList.Add(OrderingLoop);
            OrderSingleItem OrderSingleItem = new OrderSingleItem(onlineServices, "OrderSingleItem", callflow, myCall, logHeader);
            OrderSingleItem.ContactIDSetter = () => { return variableMap["callflow$.ContactID"].Value; };
            OrderingLoop.Container.ComponentList.Add(OrderSingleItem);
            ConditionalComponent CheckItemSelected = new ConditionalComponent("CheckItemSelected", callflow, myCall, logHeader);
            OrderingLoop.Container.ComponentList.Add(CheckItemSelected);
            CheckItemSelected.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.GREAT_THAN((IComparable)OrderSingleItem.ItemQuantity,(IComparable)0)); });
            CheckItemSelected.ContainerList.Add(new SequenceContainerComponent("CheckItemSelected_0", callflow, myCall, logHeader));
            MySqlDatabaseAccessComponent AddItemToOrder = new MySqlDatabaseAccessComponent("AddItemToOrder", callflow, myCall, logHeader);
            AddItemToOrder.ServerHandler = () => { return Convert.ToString(variableMap["project$.DatabaseServer"].Value); };
            AddItemToOrder.PortHandler = () => { return Convert.ToInt32(variableMap["project$.DatabasePort"].Value); };
            AddItemToOrder.DatabaseHandler = () => { return Convert.ToString(variableMap["project$.DatabaseName"].Value); };
            AddItemToOrder.UserNameHandler = () => { return Convert.ToString(variableMap["project$.DatabaseUsername"].Value); };
            AddItemToOrder.PasswordHandler = () => { return Convert.ToString(variableMap["project$.DatabasePassword"].Value); };
            AddItemToOrder.SqlStatementHandler = () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("INSERT INTO `orderdetails`(`orderid`, `index`, `itemid`, `quantity`) VALUES("),Convert.ToString(variableMap["callflow$.OrderID"].Value),Convert.ToString(","),Convert.ToString(variableMap["callflow$.ItemIndex"].Value),Convert.ToString(","),Convert.ToString(OrderSingleItem.ItemID),Convert.ToString(","),Convert.ToString(OrderSingleItem.ItemQuantity),Convert.ToString(")"))); };
            AddItemToOrder.UseConnectionString = false;
            AddItemToOrder.StatementType = DatabaseAccessComponent.StatementTypes.NonQuery;
            AddItemToOrder.Timeout = 30000;
            CheckItemSelected.ContainerList[0].ComponentList.Add(AddItemToOrder);
            IncrementVariableComponent IncrementItemIndex = new IncrementVariableComponent("IncrementItemIndex", callflow, myCall, logHeader);
            IncrementItemIndex.VariableName = "callflow$.ItemIndex";
            CheckItemSelected.ContainerList[0].ComponentList.Add(IncrementItemIndex);
            AddToTotalAmount1350713607ECCComponent AddToTotalAmount = new AddToTotalAmount1350713607ECCComponent("AddToTotalAmount", callflow, myCall, logHeader);
            AddToTotalAmount.Parameters.Add(new CallFlow.CFD.Parameter("itemPrice", () => { return OrderSingleItem.ItemPrice; }));
            AddToTotalAmount.Parameters.Add(new CallFlow.CFD.Parameter("quantity", () => { return OrderSingleItem.ItemQuantity; }));
            AddToTotalAmount.Parameters.Add(new CallFlow.CFD.Parameter("totalAmount", () => { return variableMap["callflow$.TotalAmount"].Value; }));
            CheckItemSelected.ContainerList[0].ComponentList.Add(AddToTotalAmount);
            VariableAssignmentComponent SetTotalAmount = new VariableAssignmentComponent("SetTotalAmount", callflow, myCall, logHeader);
            SetTotalAmount.VariableName = "callflow$.TotalAmount";
            SetTotalAmount.VariableValueHandler = () => { return AddToTotalAmount.ReturnValue; };
            CheckItemSelected.ContainerList[0].ComponentList.Add(SetTotalAmount);
            MenuComponent PostItemMenu = new MenuComponent("PostItemMenu", callflow, myCall, logHeader);
            PostItemMenu.AllowDtmfInput = true;
            PostItemMenu.MaxRetryCount = 2;
            PostItemMenu.Timeout = 5000;
            PostItemMenu.ValidOptionList.AddRange(new char[] { '0', '1', '2' });
            PostItemMenu.InitialPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("To add another item press 1, to complete your order press 2, or to cancel press 0."); }));
            PostItemMenu.SubsequentPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("To add another item press 1, to complete your order press 2, or to cancel press 0."); }));
            PostItemMenu.InvalidDigitPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("The selected option is invalid."); }));
            PostItemMenu.TimeoutPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We didn't receive any digit."); }));
            OrderingLoop.Container.ComponentList.Add(PostItemMenu);
            ConditionalComponent PostItemMenu_Conditional = new ConditionalComponent("PostItemMenu_Conditional", callflow, myCall, logHeader);
            OrderingLoop.Container.ComponentList.Add(PostItemMenu_Conditional);
            PostItemMenu_Conditional.ConditionList.Add(() => { return PostItemMenu.Result == MenuComponent.MenuResults.ValidOption && PostItemMenu.SelectedOption == '0'; });
            PostItemMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("PostItemMenu_Conditional_Option0", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayOrderedCanceled = new PromptPlaybackComponent("PlayOrderedCanceled", callflow, myCall, logHeader);
            PlayOrderedCanceled.AllowDtmfInput = true;
            PlayOrderedCanceled.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Your order has been canceled. Have a nice day!"); }));
            PostItemMenu_Conditional.ContainerList[0].ComponentList.Add(PlayOrderedCanceled);
            MySqlDatabaseAccessComponent SetOrderAsCanceled = new MySqlDatabaseAccessComponent("SetOrderAsCanceled", callflow, myCall, logHeader);
            SetOrderAsCanceled.ServerHandler = () => { return Convert.ToString(variableMap["project$.DatabaseServer"].Value); };
            SetOrderAsCanceled.PortHandler = () => { return Convert.ToInt32(variableMap["project$.DatabasePort"].Value); };
            SetOrderAsCanceled.DatabaseHandler = () => { return Convert.ToString(variableMap["project$.DatabaseName"].Value); };
            SetOrderAsCanceled.UserNameHandler = () => { return Convert.ToString(variableMap["project$.DatabaseUsername"].Value); };
            SetOrderAsCanceled.PasswordHandler = () => { return Convert.ToString(variableMap["project$.DatabasePassword"].Value); };
            SetOrderAsCanceled.SqlStatementHandler = () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("UPDATE orders SET status = 'Order Canceled' WHERE id ="),Convert.ToString(variableMap["callflow$.OrderID"].Value))); };
            SetOrderAsCanceled.UseConnectionString = false;
            SetOrderAsCanceled.StatementType = DatabaseAccessComponent.StatementTypes.NonQuery;
            SetOrderAsCanceled.Timeout = 30000;
            PostItemMenu_Conditional.ContainerList[0].ComponentList.Add(SetOrderAsCanceled);
            DisconnectCallComponent DropCall = new DisconnectCallComponent("DropCall", callflow, myCall, logHeader);
            PostItemMenu_Conditional.ContainerList[0].ComponentList.Add(DropCall);
            PostItemMenu_Conditional.ConditionList.Add(() => { return PostItemMenu.Result == MenuComponent.MenuResults.ValidOption && PostItemMenu.SelectedOption == '1'; });
            PostItemMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("PostItemMenu_Conditional_Option1", callflow, myCall, logHeader));
            VariableAssignmentComponent ContinueOrdering = new VariableAssignmentComponent("ContinueOrdering", callflow, myCall, logHeader);
            ContinueOrdering.VariableName = "callflow$.ContinueOrdering";
            ContinueOrdering.VariableValueHandler = () => { return true; };
            PostItemMenu_Conditional.ContainerList[1].ComponentList.Add(ContinueOrdering);
            PostItemMenu_Conditional.ConditionList.Add(() => { return PostItemMenu.Result == MenuComponent.MenuResults.ValidOption && PostItemMenu.SelectedOption == '2'; });
            PostItemMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("PostItemMenu_Conditional_Option2", callflow, myCall, logHeader));
            VariableAssignmentComponent StopOrdering = new VariableAssignmentComponent("StopOrdering", callflow, myCall, logHeader);
            StopOrdering.VariableName = "callflow$.ContinueOrdering";
            StopOrdering.VariableValueHandler = () => { return false; };
            PostItemMenu_Conditional.ContainerList[2].ComponentList.Add(StopOrdering);
            ConditionalComponent CheckOrderedItems = new ConditionalComponent("CheckOrderedItems", callflow, myCall, logHeader);
            PostItemMenu_Conditional.ContainerList[2].ComponentList.Add(CheckOrderedItems);
            CheckOrderedItems.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.GREAT_THAN((IComparable)variableMap["callflow$.ItemIndex"].Value,(IComparable)0)); });
            CheckOrderedItems.ContainerList.Add(new SequenceContainerComponent("CheckOrderedItems_0", callflow, myCall, logHeader));
            MySqlDatabaseAccessComponent SetOrderAsReady = new MySqlDatabaseAccessComponent("SetOrderAsReady", callflow, myCall, logHeader);
            SetOrderAsReady.ServerHandler = () => { return Convert.ToString(variableMap["project$.DatabaseServer"].Value); };
            SetOrderAsReady.PortHandler = () => { return Convert.ToInt32(variableMap["project$.DatabasePort"].Value); };
            SetOrderAsReady.DatabaseHandler = () => { return Convert.ToString(variableMap["project$.DatabaseName"].Value); };
            SetOrderAsReady.UserNameHandler = () => { return Convert.ToString(variableMap["project$.DatabaseUsername"].Value); };
            SetOrderAsReady.PasswordHandler = () => { return Convert.ToString(variableMap["project$.DatabasePassword"].Value); };
            SetOrderAsReady.SqlStatementHandler = () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("UPDATE orders SET status = 'Ready to Deliver' WHERE id ="),Convert.ToString(variableMap["callflow$.OrderID"].Value))); };
            SetOrderAsReady.UseConnectionString = false;
            SetOrderAsReady.StatementType = DatabaseAccessComponent.StatementTypes.NonQuery;
            SetOrderAsReady.Timeout = 30000;
            CheckOrderedItems.ContainerList[0].ComponentList.Add(SetOrderAsReady);
            ConditionalComponent CheckMailAvailable = new ConditionalComponent("CheckMailAvailable", callflow, myCall, logHeader);
            CheckOrderedItems.ContainerList[0].ComponentList.Add(CheckMailAvailable);
            CheckMailAvailable.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.GREAT_THAN((IComparable)CFDFunctions.LEN(Convert.ToString(variableMap["callflow$.ContactEmail"].Value)),(IComparable)0)); });
            CheckMailAvailable.ContainerList.Add(new SequenceContainerComponent("CheckMailAvailable_0", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayOrderDetailsEmail = new PromptPlaybackComponent("PlayOrderDetailsEmail", callflow, myCall, logHeader);
            PlayOrderDetailsEmail.AllowDtmfInput = false;
            PlayOrderDetailsEmail.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("You have ordered "),Convert.ToString(variableMap["callflow$.ItemIndex"].Value),Convert.ToString(" items with a cost of $"),Convert.ToString(variableMap["callflow$.TotalAmount"].Value),Convert.ToString(". We are sending the order details to your email address on file."))); }));
            CheckMailAvailable.ContainerList[0].ComponentList.Add(PlayOrderDetailsEmail);
            SendOrderByMail SendOrderByMail = new SendOrderByMail(onlineServices, "SendOrderByMail", callflow, myCall, logHeader);
            SendOrderByMail.ContactEmailSetter = () => { return variableMap["callflow$.ContactEmail"].Value; };
            SendOrderByMail.OrderIDSetter = () => { return variableMap["callflow$.OrderID"].Value; };
            SendOrderByMail.ItemCountSetter = () => { return variableMap["callflow$.ItemIndex"].Value; };
            SendOrderByMail.TotalAmountSetter = () => { return variableMap["callflow$.TotalAmount"].Value; };
            SendOrderByMail.ContactIDSetter = () => { return variableMap["callflow$.ContactID"].Value; };
            SendOrderByMail.ContactNameSetter = () => { return variableMap["callflow$.ContactName"].Value; };
            CheckMailAvailable.ContainerList[0].ComponentList.Add(SendOrderByMail);
            CheckMailAvailable.ConditionList.Add(() => { return Convert.ToBoolean(true); });
            CheckMailAvailable.ContainerList.Add(new SequenceContainerComponent("CheckMailAvailable_1", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayOrderDetailsFinal = new PromptPlaybackComponent("PlayOrderDetailsFinal", callflow, myCall, logHeader);
            PlayOrderDetailsFinal.AllowDtmfInput = false;
            PlayOrderDetailsFinal.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("You have ordered "),Convert.ToString(variableMap["callflow$.ItemIndex"].Value),Convert.ToString(" items with a cost of $"),Convert.ToString(variableMap["callflow$.TotalAmount"].Value),Convert.ToString(". Thank you for ordering and have a nice day!"))); }));
            CheckMailAvailable.ContainerList[1].ComponentList.Add(PlayOrderDetailsFinal);
            CheckOrderedItems.ConditionList.Add(() => { return Convert.ToBoolean(true); });
            CheckOrderedItems.ContainerList.Add(new SequenceContainerComponent("CheckOrderedItems_1", callflow, myCall, logHeader));
            MySqlDatabaseAccessComponent CancelOrder = new MySqlDatabaseAccessComponent("CancelOrder", callflow, myCall, logHeader);
            CancelOrder.ServerHandler = () => { return Convert.ToString(variableMap["project$.DatabaseServer"].Value); };
            CancelOrder.PortHandler = () => { return Convert.ToInt32(variableMap["project$.DatabasePort"].Value); };
            CancelOrder.DatabaseHandler = () => { return Convert.ToString(variableMap["project$.DatabaseName"].Value); };
            CancelOrder.UserNameHandler = () => { return Convert.ToString(variableMap["project$.DatabaseUsername"].Value); };
            CancelOrder.PasswordHandler = () => { return Convert.ToString(variableMap["project$.DatabasePassword"].Value); };
            CancelOrder.SqlStatementHandler = () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("UPDATE orders SET status = 'Order Canceled' WHERE id ="),Convert.ToString(variableMap["callflow$.OrderID"].Value))); };
            CancelOrder.UseConnectionString = false;
            CancelOrder.StatementType = DatabaseAccessComponent.StatementTypes.NonQuery;
            CancelOrder.Timeout = 30000;
            CheckOrderedItems.ContainerList[1].ComponentList.Add(CancelOrder);
            PromptPlaybackComponent GoodBye = new PromptPlaybackComponent("GoodBye", callflow, myCall, logHeader);
            GoodBye.AllowDtmfInput = true;
            GoodBye.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Thank you for ordering from Super Easy Teleshopping. Have a nice day!"); }));
            CheckOrderedItems.ContainerList[1].ComponentList.Add(GoodBye);
            PostItemMenu_Conditional.ConditionList.Add(() => { return PostItemMenu.Result == MenuComponent.MenuResults.InvalidOption || PostItemMenu.Result == MenuComponent.MenuResults.Timeout; });
            PostItemMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("PostItemMenu_Conditional_TimeoutOrInvalidOption", callflow, myCall, logHeader));
            VariableAssignmentComponent ContinueOrderingOnTimeout = new VariableAssignmentComponent("ContinueOrderingOnTimeout", callflow, myCall, logHeader);
            ContinueOrderingOnTimeout.VariableName = "callflow$.ContinueOrdering";
            ContinueOrderingOnTimeout.VariableValueHandler = () => { return true; };
            PostItemMenu_Conditional.ContainerList[3].ComponentList.Add(ContinueOrderingOnTimeout);
            }
            {
            }
            {
            }
            
            }
            
            public OrderMultipleItems(OnlineServices onlineServices, string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
                this.onlineServices = onlineServices;
            }

            protected override void GetVariableValues()
            {
                if (_ContactIDHandler != null) componentVariableMap["callflow$.ContactID"].Set(_ContactIDHandler());
                if (_ContactNameHandler != null) componentVariableMap["callflow$.ContactName"].Set(_ContactNameHandler());
                if (_ContactEmailHandler != null) componentVariableMap["callflow$.ContactEmail"].Set(_ContactEmailHandler());
                if (_ContinueOrderingHandler != null) componentVariableMap["callflow$.ContinueOrdering"].Set(_ContinueOrderingHandler());
                if (_OrderIDHandler != null) componentVariableMap["callflow$.OrderID"].Set(_OrderIDHandler());
                if (_ItemIndexHandler != null) componentVariableMap["callflow$.ItemIndex"].Set(_ItemIndexHandler());
                if (_TotalAmountHandler != null) componentVariableMap["callflow$.TotalAmount"].Set(_TotalAmountHandler());
                
            }
            
            public ObjectExpressionHandler ContactIDSetter { set { _ContactIDHandler = value; } }
            public object ContactID { get { return componentVariableMap["callflow$.ContactID"].Value; } }
            public ObjectExpressionHandler ContactNameSetter { set { _ContactNameHandler = value; } }
            public object ContactName { get { return componentVariableMap["callflow$.ContactName"].Value; } }
            public ObjectExpressionHandler ContactEmailSetter { set { _ContactEmailHandler = value; } }
            public object ContactEmail { get { return componentVariableMap["callflow$.ContactEmail"].Value; } }
            public ObjectExpressionHandler ContinueOrderingSetter { set { _ContinueOrderingHandler = value; } }
            public object ContinueOrdering { get { return componentVariableMap["callflow$.ContinueOrdering"].Value; } }
            public ObjectExpressionHandler OrderIDSetter { set { _OrderIDHandler = value; } }
            public object OrderID { get { return componentVariableMap["callflow$.OrderID"].Value; } }
            public ObjectExpressionHandler ItemIndexSetter { set { _ItemIndexHandler = value; } }
            public object ItemIndex { get { return componentVariableMap["callflow$.ItemIndex"].Value; } }
            public ObjectExpressionHandler TotalAmountSetter { set { _TotalAmountHandler = value; } }
            public object TotalAmount { get { return componentVariableMap["callflow$.TotalAmount"].Value; } }
            

            private bool IsServerOfficeHourActive(ICall myCall)
            {
                DateTime nowDt = DateTime.Now;
                Tenant tenant = myCall.PS.GetTenant();
                if (tenant == null || tenant.IsHoliday(new DateTimeOffset(nowDt)))
                    return false;

                string overrideOfficeTime = tenant.GetPropertyValue("OVERRIDEOFFICETIME");
                if (!String.IsNullOrEmpty(overrideOfficeTime))
                {
                    if (overrideOfficeTime == "1") // Forced to in office hours
                        return true;
                    else if (overrideOfficeTime == "2") // Forced to out of office hours
                        return false;
                }

                Schedule officeHours = tenant.Hours;
                Nullable<bool> result = officeHours.IsActiveTime(nowDt);
                return result.GetValueOrDefault(false);
            }
        }
public class AddToTotalAmount1350713607ECCComponent : ExternalCodeExecutionComponent
            {
                public List<CallFlow.CFD.Parameter> Parameters { get; } = new List<CallFlow.CFD.Parameter>();
                public AddToTotalAmount1350713607ECCComponent(string name, ICallflow callflow, ICall myCall, string projectName) : base(name, callflow, myCall, projectName) {}
                protected override object ExecuteCode()
                {
                    return AddToTotalAmount(Convert.ToDecimal(Parameters[0].Value), Convert.ToInt32(Parameters[1].Value), Convert.ToDecimal(Parameters[2].Value));
                }
            
            private object AddToTotalAmount(decimal itemPrice, int quantity, decimal totalAmount)
                {
            return itemPrice * quantity + totalAmount;    }
            }
                    // ------------------------------------------------------------------------------------------------------------
        // User Defined component
        // ------------------------------------------------------------------------------------------------------------
        public class OrderSingleItem : AbsUserComponent
        {
            private OnlineServices onlineServices;

            private ObjectExpressionHandler _ContactIDHandler = null;
            private ObjectExpressionHandler _ItemIDHandler = null;
            private ObjectExpressionHandler _ItemDescriptionHandler = null;
            private ObjectExpressionHandler _ItemQuantityHandler = null;
            private ObjectExpressionHandler _ItemPriceHandler = null;
            

            protected override void InitializeVariables()
            {
                componentVariableMap["callflow$.ContactID"] = new Variable("");
                componentVariableMap["callflow$.ItemID"] = new Variable("");
                componentVariableMap["callflow$.ItemDescription"] = new Variable("");
                componentVariableMap["callflow$.ItemQuantity"] = new Variable(0);
                componentVariableMap["callflow$.ItemPrice"] = new Variable(0);
                
            }

            protected override void InitializeComponents()
            {
                Dictionary<string, Variable> variableMap = componentVariableMap;
                {
            UserInputComponent EnterItemID = new UserInputComponent("EnterItemID", callflow, myCall, logHeader);
            EnterItemID.AllowDtmfInput = true;
            EnterItemID.MaxRetryCount = 2;
            EnterItemID.FirstDigitTimeout = 5000;
            EnterItemID.InterDigitTimeout = 3000;
            EnterItemID.FinalDigitTimeout = 2000;
            EnterItemID.MinDigits = 6;
            EnterItemID.MaxDigits = 6;
            EnterItemID.ValidDigitList.AddRange(new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' });
            EnterItemID.InitialPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Please enter the item number from our catalog or web site to order."); }));
            EnterItemID.SubsequentPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Please enter the item number from our catalog or web site to order."); }));
            EnterItemID.InvalidDigitPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("You need to enter 6 digits."); }));
            EnterItemID.TimeoutPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We didn't receive any digit."); }));
            mainFlowComponentList.Add(EnterItemID);
            ConditionalComponent EnterItemID_Conditional = new ConditionalComponent("EnterItemID_Conditional", callflow, myCall, logHeader);
            mainFlowComponentList.Add(EnterItemID_Conditional);
            EnterItemID_Conditional.ConditionList.Add(() => { return EnterItemID.Result == UserInputComponent.UserInputResults.ValidDigits; });
            EnterItemID_Conditional.ContainerList.Add(new SequenceContainerComponent("EnterItemID_Conditional_ValidInput", callflow, myCall, logHeader));
            MySqlDatabaseAccessComponent GetItemDetails = new MySqlDatabaseAccessComponent("GetItemDetails", callflow, myCall, logHeader);
            GetItemDetails.ServerHandler = () => { return Convert.ToString(variableMap["project$.DatabaseServer"].Value); };
            GetItemDetails.PortHandler = () => { return Convert.ToInt32(variableMap["project$.DatabasePort"].Value); };
            GetItemDetails.DatabaseHandler = () => { return Convert.ToString(variableMap["project$.DatabaseName"].Value); };
            GetItemDetails.UserNameHandler = () => { return Convert.ToString(variableMap["project$.DatabaseUsername"].Value); };
            GetItemDetails.PasswordHandler = () => { return Convert.ToString(variableMap["project$.DatabasePassword"].Value); };
            GetItemDetails.SqlStatementHandler = () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("SELECT name, stock, price FROM items WHERE id="),Convert.ToString(EnterItemID.Buffer))); };
            GetItemDetails.UseConnectionString = false;
            GetItemDetails.StatementType = DatabaseAccessComponent.StatementTypes.Query;
            GetItemDetails.Timeout = 30000;
            EnterItemID_Conditional.ContainerList[0].ComponentList.Add(GetItemDetails);
            ConditionalComponent CheckAvailability = new ConditionalComponent("CheckAvailability", callflow, myCall, logHeader);
            EnterItemID_Conditional.ContainerList[0].ComponentList.Add(CheckAvailability);
            CheckAvailability.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.EQUAL(CFDFunctions.GET_TABLE_ROW_COUNT(GetItemDetails.QueryResult),0)); });
            CheckAvailability.ContainerList.Add(new SequenceContainerComponent("CheckAvailability_0", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayInvalidItem = new PromptPlaybackComponent("PlayInvalidItem", callflow, myCall, logHeader);
            PlayInvalidItem.AllowDtmfInput = true;
            PlayInvalidItem.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("This item number is invalid."); }));
            CheckAvailability.ContainerList[0].ComponentList.Add(PlayInvalidItem);
            CheckAvailability.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.EQUAL(CFDFunctions.GET_TABLE_CELL_VALUE(GetItemDetails.QueryResult,Convert.ToInt32(0),Convert.ToInt32(1)),0)); });
            CheckAvailability.ContainerList.Add(new SequenceContainerComponent("CheckAvailability_1", callflow, myCall, logHeader));
            ItemAddNotification OfferNotification = new ItemAddNotification(onlineServices, "OfferNotification", callflow, myCall, logHeader);
            OfferNotification.ContactIDSetter = () => { return variableMap["callflow$.ContactID"].Value; };
            OfferNotification.ItemIDSetter = () => { return EnterItemID.Buffer; };
            CheckAvailability.ContainerList[1].ComponentList.Add(OfferNotification);
            CheckAvailability.ConditionList.Add(() => { return Convert.ToBoolean(true); });
            CheckAvailability.ContainerList.Add(new SequenceContainerComponent("CheckAvailability_2", callflow, myCall, logHeader));
            VariableAssignmentComponent SetItemID = new VariableAssignmentComponent("SetItemID", callflow, myCall, logHeader);
            SetItemID.VariableName = "callflow$.ItemID";
            SetItemID.VariableValueHandler = () => { return EnterItemID.Buffer; };
            CheckAvailability.ContainerList[2].ComponentList.Add(SetItemID);
            VariableAssignmentComponent SetItemDescription = new VariableAssignmentComponent("SetItemDescription", callflow, myCall, logHeader);
            SetItemDescription.VariableName = "callflow$.ItemDescription";
            SetItemDescription.VariableValueHandler = () => { return CFDFunctions.GET_TABLE_CELL_VALUE(GetItemDetails.QueryResult,Convert.ToInt32(0),Convert.ToInt32(0)); };
            CheckAvailability.ContainerList[2].ComponentList.Add(SetItemDescription);
            VariableAssignmentComponent SetItemPrice = new VariableAssignmentComponent("SetItemPrice", callflow, myCall, logHeader);
            SetItemPrice.VariableName = "callflow$.ItemPrice";
            SetItemPrice.VariableValueHandler = () => { return CFDFunctions.GET_TABLE_CELL_VALUE(GetItemDetails.QueryResult,Convert.ToInt32(0),Convert.ToInt32(2)); };
            CheckAvailability.ContainerList[2].ComponentList.Add(SetItemPrice);
            PromptPlaybackComponent PlayItemDescription = new PromptPlaybackComponent("PlayItemDescription", callflow, myCall, logHeader);
            PlayItemDescription.AllowDtmfInput = true;
            PlayItemDescription.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("You've selected the following item: "),Convert.ToString(variableMap["callflow$.ItemDescription"].Value))); }));
            CheckAvailability.ContainerList[2].ComponentList.Add(PlayItemDescription);
            ItemChangeQuantity OfferChangeQuantity = new ItemChangeQuantity(onlineServices, "OfferChangeQuantity", callflow, myCall, logHeader);
            OfferChangeQuantity.MaxQuantitySetter = () => { return CFDFunctions.GET_TABLE_CELL_VALUE(GetItemDetails.QueryResult,Convert.ToInt32(0),Convert.ToInt32(1)); };
            CheckAvailability.ContainerList[2].ComponentList.Add(OfferChangeQuantity);
            ConditionalComponent CheckQuantity = new ConditionalComponent("CheckQuantity", callflow, myCall, logHeader);
            CheckAvailability.ContainerList[2].ComponentList.Add(CheckQuantity);
            CheckQuantity.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.EQUAL(OfferChangeQuantity.SelectedQuantity,0)); });
            CheckQuantity.ContainerList.Add(new SequenceContainerComponent("CheckQuantity_0", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayItemCanceled = new PromptPlaybackComponent("PlayItemCanceled", callflow, myCall, logHeader);
            PlayItemCanceled.AllowDtmfInput = true;
            PlayItemCanceled.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Removed this item from your order."); }));
            CheckQuantity.ContainerList[0].ComponentList.Add(PlayItemCanceled);
            CheckQuantity.ConditionList.Add(() => { return Convert.ToBoolean(true); });
            CheckQuantity.ContainerList.Add(new SequenceContainerComponent("CheckQuantity_1", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayItemDetails = new PromptPlaybackComponent("PlayItemDetails", callflow, myCall, logHeader);
            PlayItemDetails.AllowDtmfInput = true;
            PlayItemDetails.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("Added a quantity of "),Convert.ToString(OfferChangeQuantity.SelectedQuantity),Convert.ToString(" for this item to your order."))); }));
            CheckQuantity.ContainerList[1].ComponentList.Add(PlayItemDetails);
            VariableAssignmentComponent SetQuantity = new VariableAssignmentComponent("SetQuantity", callflow, myCall, logHeader);
            SetQuantity.VariableName = "callflow$.ItemQuantity";
            SetQuantity.VariableValueHandler = () => { return OfferChangeQuantity.SelectedQuantity; };
            CheckQuantity.ContainerList[1].ComponentList.Add(SetQuantity);
            EnterItemID_Conditional.ConditionList.Add(() => { return EnterItemID.Result == UserInputComponent.UserInputResults.InvalidDigits || EnterItemID.Result == UserInputComponent.UserInputResults.Timeout; });
            EnterItemID_Conditional.ContainerList.Add(new SequenceContainerComponent("EnterItemID_Conditional_InvalidInput", callflow, myCall, logHeader));
            PromptPlaybackComponent PlayNoItemSelected = new PromptPlaybackComponent("PlayNoItemSelected", callflow, myCall, logHeader);
            PlayNoItemSelected.AllowDtmfInput = true;
            PlayNoItemSelected.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("We couldn't identify the item."); }));
            EnterItemID_Conditional.ContainerList[1].ComponentList.Add(PlayNoItemSelected);
            }
            {
            }
            {
            }
            
            }
            
            public OrderSingleItem(OnlineServices onlineServices, string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
                this.onlineServices = onlineServices;
            }

            protected override void GetVariableValues()
            {
                if (_ContactIDHandler != null) componentVariableMap["callflow$.ContactID"].Set(_ContactIDHandler());
                if (_ItemIDHandler != null) componentVariableMap["callflow$.ItemID"].Set(_ItemIDHandler());
                if (_ItemDescriptionHandler != null) componentVariableMap["callflow$.ItemDescription"].Set(_ItemDescriptionHandler());
                if (_ItemQuantityHandler != null) componentVariableMap["callflow$.ItemQuantity"].Set(_ItemQuantityHandler());
                if (_ItemPriceHandler != null) componentVariableMap["callflow$.ItemPrice"].Set(_ItemPriceHandler());
                
            }
            
            public ObjectExpressionHandler ContactIDSetter { set { _ContactIDHandler = value; } }
            public object ContactID { get { return componentVariableMap["callflow$.ContactID"].Value; } }
            public ObjectExpressionHandler ItemIDSetter { set { _ItemIDHandler = value; } }
            public object ItemID { get { return componentVariableMap["callflow$.ItemID"].Value; } }
            public ObjectExpressionHandler ItemDescriptionSetter { set { _ItemDescriptionHandler = value; } }
            public object ItemDescription { get { return componentVariableMap["callflow$.ItemDescription"].Value; } }
            public ObjectExpressionHandler ItemQuantitySetter { set { _ItemQuantityHandler = value; } }
            public object ItemQuantity { get { return componentVariableMap["callflow$.ItemQuantity"].Value; } }
            public ObjectExpressionHandler ItemPriceSetter { set { _ItemPriceHandler = value; } }
            public object ItemPrice { get { return componentVariableMap["callflow$.ItemPrice"].Value; } }
            

            private bool IsServerOfficeHourActive(ICall myCall)
            {
                DateTime nowDt = DateTime.Now;
                Tenant tenant = myCall.PS.GetTenant();
                if (tenant == null || tenant.IsHoliday(new DateTimeOffset(nowDt)))
                    return false;

                string overrideOfficeTime = tenant.GetPropertyValue("OVERRIDEOFFICETIME");
                if (!String.IsNullOrEmpty(overrideOfficeTime))
                {
                    if (overrideOfficeTime == "1") // Forced to in office hours
                        return true;
                    else if (overrideOfficeTime == "2") // Forced to out of office hours
                        return false;
                }

                Schedule officeHours = tenant.Hours;
                Nullable<bool> result = officeHours.IsActiveTime(nowDt);
                return result.GetValueOrDefault(false);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        // User Defined component
        // ------------------------------------------------------------------------------------------------------------
        public class SendOrderByMail : AbsUserComponent
        {
            private OnlineServices onlineServices;

            private ObjectExpressionHandler _OrderIDHandler = null;
            private ObjectExpressionHandler _ContactIDHandler = null;
            private ObjectExpressionHandler _ContactNameHandler = null;
            private ObjectExpressionHandler _ContactEmailHandler = null;
            private ObjectExpressionHandler _TotalAmountHandler = null;
            private ObjectExpressionHandler _ItemCountHandler = null;
            private ObjectExpressionHandler _ItemIndexHandler = null;
            private ObjectExpressionHandler _MailBodyHandler = null;
            private ObjectExpressionHandler _DataIDHandler = null;
            private ObjectExpressionHandler _DataDescriptionHandler = null;
            private ObjectExpressionHandler _DataQuantityHandler = null;
            private ObjectExpressionHandler _DataPriceHandler = null;
            

            protected override void InitializeVariables()
            {
                componentVariableMap["callflow$.OrderID"] = new Variable("");
                componentVariableMap["callflow$.ContactID"] = new Variable("");
                componentVariableMap["callflow$.ContactName"] = new Variable("");
                componentVariableMap["callflow$.ContactEmail"] = new Variable("");
                componentVariableMap["callflow$.TotalAmount"] = new Variable("");
                componentVariableMap["callflow$.ItemCount"] = new Variable("");
                componentVariableMap["callflow$.ItemIndex"] = new Variable(0);
                componentVariableMap["callflow$.MailBody"] = new Variable("");
                componentVariableMap["callflow$.DataID"] = new Variable("");
                componentVariableMap["callflow$.DataDescription"] = new Variable("");
                componentVariableMap["callflow$.DataQuantity"] = new Variable("");
                componentVariableMap["callflow$.DataPrice"] = new Variable("");
                
            }

            protected override void InitializeComponents()
            {
                Dictionary<string, Variable> variableMap = componentVariableMap;
                {
            VariableAssignmentComponent SetMailBody = new VariableAssignmentComponent("SetMailBody", callflow, myCall, logHeader);
            SetMailBody.VariableName = "callflow$.MailBody";
            SetMailBody.VariableValueHandler = () => { return CFDFunctions.CONCATENATE(Convert.ToString("<p><b>Customer Number:</b> "),Convert.ToString(variableMap["callflow$.ContactID"].Value),Convert.ToString("</p><p><b>Customer Name:</b> "),Convert.ToString(variableMap["callflow$.ContactName"].Value),Convert.ToString("</p><p><b>Order details</b></p><br/><table><tr><td><b>Item ID</b></td><td><b>Description</b></td><td><b>Quantity</b></td><td><b>Unit Price</b></td><td><b>Total</b></td></tr>")); };
            mainFlowComponentList.Add(SetMailBody);
            LoopComponent ItemsLoop = new LoopComponent("ItemsLoop", callflow, myCall, logHeader);
            ItemsLoop.Condition = () => { return Convert.ToBoolean(CFDFunctions.LESS_THAN((IComparable)variableMap["callflow$.ItemIndex"].Value,(IComparable)variableMap["callflow$.ItemCount"].Value)); };
            ItemsLoop.Container = new SequenceContainerComponent("ItemsLoop_Container", callflow, myCall, logHeader);
            mainFlowComponentList.Add(ItemsLoop);
            MySqlDatabaseAccessComponent GetOrderItem = new MySqlDatabaseAccessComponent("GetOrderItem", callflow, myCall, logHeader);
            GetOrderItem.ServerHandler = () => { return Convert.ToString(variableMap["project$.DatabaseServer"].Value); };
            GetOrderItem.PortHandler = () => { return Convert.ToInt32(variableMap["project$.DatabasePort"].Value); };
            GetOrderItem.DatabaseHandler = () => { return Convert.ToString(variableMap["project$.DatabaseName"].Value); };
            GetOrderItem.UserNameHandler = () => { return Convert.ToString(variableMap["project$.DatabaseUsername"].Value); };
            GetOrderItem.PasswordHandler = () => { return Convert.ToString(variableMap["project$.DatabasePassword"].Value); };
            GetOrderItem.SqlStatementHandler = () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("SELECT A.itemid, B.name, A.quantity, B.price FROM orderdetails as A, items as B WHERE A.itemid = B.id AND A.orderid = "),Convert.ToString(variableMap["callflow$.OrderID"].Value),Convert.ToString(" AND A.index = "),Convert.ToString(variableMap["callflow$.ItemIndex"].Value))); };
            GetOrderItem.UseConnectionString = false;
            GetOrderItem.StatementType = DatabaseAccessComponent.StatementTypes.Query;
            GetOrderItem.Timeout = 30000;
            ItemsLoop.Container.ComponentList.Add(GetOrderItem);
            VariableAssignmentComponent SetItemID = new VariableAssignmentComponent("SetItemID", callflow, myCall, logHeader);
            SetItemID.VariableName = "callflow$.DataID";
            SetItemID.VariableValueHandler = () => { return CFDFunctions.GET_TABLE_CELL_VALUE(GetOrderItem.QueryResult,Convert.ToInt32(0),Convert.ToInt32(0)); };
            ItemsLoop.Container.ComponentList.Add(SetItemID);
            VariableAssignmentComponent SetItemDescription = new VariableAssignmentComponent("SetItemDescription", callflow, myCall, logHeader);
            SetItemDescription.VariableName = "callflow$.DataDescription";
            SetItemDescription.VariableValueHandler = () => { return CFDFunctions.GET_TABLE_CELL_VALUE(GetOrderItem.QueryResult,Convert.ToInt32(0),Convert.ToInt32(1)); };
            ItemsLoop.Container.ComponentList.Add(SetItemDescription);
            VariableAssignmentComponent SetItemQuantity = new VariableAssignmentComponent("SetItemQuantity", callflow, myCall, logHeader);
            SetItemQuantity.VariableName = "callflow$.DataQuantity";
            SetItemQuantity.VariableValueHandler = () => { return CFDFunctions.GET_TABLE_CELL_VALUE(GetOrderItem.QueryResult,Convert.ToInt32(0),Convert.ToInt32(2)); };
            ItemsLoop.Container.ComponentList.Add(SetItemQuantity);
            VariableAssignmentComponent SetItemPrice = new VariableAssignmentComponent("SetItemPrice", callflow, myCall, logHeader);
            SetItemPrice.VariableName = "callflow$.DataPrice";
            SetItemPrice.VariableValueHandler = () => { return CFDFunctions.GET_TABLE_CELL_VALUE(GetOrderItem.QueryResult,Convert.ToInt32(0),Convert.ToInt32(3)); };
            ItemsLoop.Container.ComponentList.Add(SetItemPrice);
            CalculateItemTotal271778119ECCComponent CalculateItemTotal = new CalculateItemTotal271778119ECCComponent("CalculateItemTotal", callflow, myCall, logHeader);
            CalculateItemTotal.Parameters.Add(new CallFlow.CFD.Parameter("quantity", () => { return variableMap["callflow$.DataQuantity"].Value; }));
            CalculateItemTotal.Parameters.Add(new CallFlow.CFD.Parameter("unitPrice", () => { return variableMap["callflow$.DataPrice"].Value; }));
            ItemsLoop.Container.ComponentList.Add(CalculateItemTotal);
            VariableAssignmentComponent AddTableRowToMailBody = new VariableAssignmentComponent("AddTableRowToMailBody", callflow, myCall, logHeader);
            AddTableRowToMailBody.VariableName = "callflow$.MailBody";
            AddTableRowToMailBody.VariableValueHandler = () => { return CFDFunctions.CONCATENATE(Convert.ToString(variableMap["callflow$.MailBody"].Value),Convert.ToString("<tr><td>"),Convert.ToString(variableMap["callflow$.DataID"].Value),Convert.ToString("</td><td>"),Convert.ToString(variableMap["callflow$.DataDescription"].Value),Convert.ToString("</td><td>"),Convert.ToString(variableMap["callflow$.DataQuantity"].Value),Convert.ToString("</td><td>$"),Convert.ToString(variableMap["callflow$.DataPrice"].Value),Convert.ToString("</td><td>$"),Convert.ToString(CalculateItemTotal.ReturnValue),Convert.ToString("</td></tr>")); };
            ItemsLoop.Container.ComponentList.Add(AddTableRowToMailBody);
            IncrementVariableComponent IncrementIndex = new IncrementVariableComponent("IncrementIndex", callflow, myCall, logHeader);
            IncrementIndex.VariableName = "callflow$.ItemIndex";
            ItemsLoop.Container.ComponentList.Add(IncrementIndex);
            VariableAssignmentComponent CloseMailBody = new VariableAssignmentComponent("CloseMailBody", callflow, myCall, logHeader);
            CloseMailBody.VariableName = "callflow$.MailBody";
            CloseMailBody.VariableValueHandler = () => { return CFDFunctions.CONCATENATE(Convert.ToString(variableMap["callflow$.MailBody"].Value),Convert.ToString("<tr><td colspan=\"4\">TOTAL</td><td>$"),Convert.ToString(variableMap["callflow$.TotalAmount"].Value),Convert.ToString("</td></tr></table><p>You can check the status of your order by calling back, use option 2, and dial the order reference number.</p>")); };
            mainFlowComponentList.Add(CloseMailBody);
            EMailSenderComponent SendMail = new EMailSenderComponent("SendMail", callflow, myCall, logHeader);
            SendMail.UseServerSettings = true;
            SendMail.ToHandler = () => { return Convert.ToString(variableMap["callflow$.ContactEmail"].Value); };
            SendMail.SubjectHandler = () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("Summary for your Order Ref. #"),Convert.ToString(variableMap["callflow$.OrderID"].Value))); };
            SendMail.BodyHandler = () => { return Convert.ToString(variableMap["callflow$.MailBody"].Value); };
            SendMail.IsBodyHtml = true;
            SendMail.Priority = MessagePriority.Normal;
            SendMail.IgnoreMissingAttachments = false;
            mainFlowComponentList.Add(SendMail);
            PromptPlaybackComponent MessageSent = new PromptPlaybackComponent("MessageSent", callflow, myCall, logHeader);
            MessageSent.AllowDtmfInput = true;
            MessageSent.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Amy", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Order sent. Thank you for ordering and have a nice day!"); }));
            mainFlowComponentList.Add(MessageSent);
            }
            {
            }
            {
            }
            
            }
            
            public SendOrderByMail(OnlineServices onlineServices, string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
                this.onlineServices = onlineServices;
            }

            protected override void GetVariableValues()
            {
                if (_OrderIDHandler != null) componentVariableMap["callflow$.OrderID"].Set(_OrderIDHandler());
                if (_ContactIDHandler != null) componentVariableMap["callflow$.ContactID"].Set(_ContactIDHandler());
                if (_ContactNameHandler != null) componentVariableMap["callflow$.ContactName"].Set(_ContactNameHandler());
                if (_ContactEmailHandler != null) componentVariableMap["callflow$.ContactEmail"].Set(_ContactEmailHandler());
                if (_TotalAmountHandler != null) componentVariableMap["callflow$.TotalAmount"].Set(_TotalAmountHandler());
                if (_ItemCountHandler != null) componentVariableMap["callflow$.ItemCount"].Set(_ItemCountHandler());
                if (_ItemIndexHandler != null) componentVariableMap["callflow$.ItemIndex"].Set(_ItemIndexHandler());
                if (_MailBodyHandler != null) componentVariableMap["callflow$.MailBody"].Set(_MailBodyHandler());
                if (_DataIDHandler != null) componentVariableMap["callflow$.DataID"].Set(_DataIDHandler());
                if (_DataDescriptionHandler != null) componentVariableMap["callflow$.DataDescription"].Set(_DataDescriptionHandler());
                if (_DataQuantityHandler != null) componentVariableMap["callflow$.DataQuantity"].Set(_DataQuantityHandler());
                if (_DataPriceHandler != null) componentVariableMap["callflow$.DataPrice"].Set(_DataPriceHandler());
                
            }
            
            public ObjectExpressionHandler OrderIDSetter { set { _OrderIDHandler = value; } }
            public object OrderID { get { return componentVariableMap["callflow$.OrderID"].Value; } }
            public ObjectExpressionHandler ContactIDSetter { set { _ContactIDHandler = value; } }
            public object ContactID { get { return componentVariableMap["callflow$.ContactID"].Value; } }
            public ObjectExpressionHandler ContactNameSetter { set { _ContactNameHandler = value; } }
            public object ContactName { get { return componentVariableMap["callflow$.ContactName"].Value; } }
            public ObjectExpressionHandler ContactEmailSetter { set { _ContactEmailHandler = value; } }
            public object ContactEmail { get { return componentVariableMap["callflow$.ContactEmail"].Value; } }
            public ObjectExpressionHandler TotalAmountSetter { set { _TotalAmountHandler = value; } }
            public object TotalAmount { get { return componentVariableMap["callflow$.TotalAmount"].Value; } }
            public ObjectExpressionHandler ItemCountSetter { set { _ItemCountHandler = value; } }
            public object ItemCount { get { return componentVariableMap["callflow$.ItemCount"].Value; } }
            public ObjectExpressionHandler ItemIndexSetter { set { _ItemIndexHandler = value; } }
            public object ItemIndex { get { return componentVariableMap["callflow$.ItemIndex"].Value; } }
            public ObjectExpressionHandler MailBodySetter { set { _MailBodyHandler = value; } }
            public object MailBody { get { return componentVariableMap["callflow$.MailBody"].Value; } }
            public ObjectExpressionHandler DataIDSetter { set { _DataIDHandler = value; } }
            public object DataID { get { return componentVariableMap["callflow$.DataID"].Value; } }
            public ObjectExpressionHandler DataDescriptionSetter { set { _DataDescriptionHandler = value; } }
            public object DataDescription { get { return componentVariableMap["callflow$.DataDescription"].Value; } }
            public ObjectExpressionHandler DataQuantitySetter { set { _DataQuantityHandler = value; } }
            public object DataQuantity { get { return componentVariableMap["callflow$.DataQuantity"].Value; } }
            public ObjectExpressionHandler DataPriceSetter { set { _DataPriceHandler = value; } }
            public object DataPrice { get { return componentVariableMap["callflow$.DataPrice"].Value; } }
            

            private bool IsServerOfficeHourActive(ICall myCall)
            {
                DateTime nowDt = DateTime.Now;
                Tenant tenant = myCall.PS.GetTenant();
                if (tenant == null || tenant.IsHoliday(new DateTimeOffset(nowDt)))
                    return false;

                string overrideOfficeTime = tenant.GetPropertyValue("OVERRIDEOFFICETIME");
                if (!String.IsNullOrEmpty(overrideOfficeTime))
                {
                    if (overrideOfficeTime == "1") // Forced to in office hours
                        return true;
                    else if (overrideOfficeTime == "2") // Forced to out of office hours
                        return false;
                }

                Schedule officeHours = tenant.Hours;
                Nullable<bool> result = officeHours.IsActiveTime(nowDt);
                return result.GetValueOrDefault(false);
            }
        }
public class CalculateItemTotal271778119ECCComponent : ExternalCodeExecutionComponent
            {
                public List<CallFlow.CFD.Parameter> Parameters { get; } = new List<CallFlow.CFD.Parameter>();
                public CalculateItemTotal271778119ECCComponent(string name, ICallflow callflow, ICall myCall, string projectName) : base(name, callflow, myCall, projectName) {}
                protected override object ExecuteCode()
                {
                    return CalculateItemTotal(Convert.ToInt32(Parameters[0].Value), Convert.ToDecimal(Parameters[1].Value));
                }
            
            private object CalculateItemTotal(int quantity, decimal unitPrice)
                {
            return quantity * unitPrice;    }
            }
            
    }
}
