using CallFlow.CFD;
using CallFlow;
using MimeKit;
using MySql.Data.MySqlClient;
using Npgsql;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Text;
using System.Threading.Tasks.Dataflow;
using System.Threading.Tasks;
using System.Threading;
using System;
using TCX.Configuration;

namespace CFD_3
{
    public class Main : ScriptBase<Main>, ICallflow, ICallflowProcessor
    {
        private bool executionStarted;
        private bool executionFinished;

        private BufferBlock<AbsEvent> eventBuffer;

        private int currentComponentIndex;
        private List<AbsComponent> mainFlowComponentList;
        private List<AbsComponent> disconnectFlowComponentList;
        private List<AbsComponent> errorFlowComponentList;
        private List<AbsComponent> currentFlowComponentList;

        private LogFormatter logFormatter;
        private TimerManager timerManager;
        private Dictionary<string, Variable> variableMap;
        private TempWavFileManager tempWavFileManager;
        private PromptQueue promptQueue;

        private void DisconnectCallAndExitCallflow()
        {
            logFormatter.Trace("Callflow finished, disconnecting call...");
            MyCall.Terminate();
        }

        private async Task ExecuteErrorFlow()
        {
            if (currentFlowComponentList == errorFlowComponentList)
            {
                logFormatter.Trace("Error during error handler flow, exiting callflow...");
                DisconnectCallAndExitCallflow();
            }
            else
            {
                currentFlowComponentList = errorFlowComponentList;
                currentComponentIndex = 0;
                if (errorFlowComponentList.Count > 0)
                {
                    logFormatter.Trace("Start executing error handler flow...");
                    await ProcessStart();
                }
                else
                {
                    logFormatter.Trace("Error handler flow is empty...");
                    DisconnectCallAndExitCallflow();
                }
            }
        }

        private EventResults CheckEventResult(EventResults eventResult)
        {
            if (eventResult == EventResults.MoveToNextComponent && ++currentComponentIndex == currentFlowComponentList.Count)
            {
                DisconnectCallAndExitCallflow();
                return EventResults.Exit;
            }
            else if (eventResult == EventResults.Exit)
                DisconnectCallAndExitCallflow();

            return eventResult;
        }

        private void InitializeVariables(string callID)
        {
            // Call variables
            variableMap["session.ani"] = new Variable(MyCall.Caller.CallerID);
            variableMap["session.callid"] = new Variable(callID);
            variableMap["session.dnis"] = new Variable(MyCall.DN.Number);
            variableMap["session.did"] = new Variable(MyCall.Caller.CalledNumber);
            variableMap["session.audioFolder"] = new Variable(Path.Combine(RecordingManager.Instance.AudioFolder, promptQueue.ProjectAudioFolder));
            variableMap["session.transferingExtension"] = new Variable(MyCall["onbehlfof"] ?? string.Empty);

            // Standard variables
            variableMap["RecordResult.NothingRecorded"] = new Variable(RecordComponent.RecordResults.NothingRecorded);
            variableMap["RecordResult.StopDigit"] = new Variable(RecordComponent.RecordResults.StopDigit);
            variableMap["RecordResult.Completed"] = new Variable(RecordComponent.RecordResults.Completed);
            variableMap["MenuResult.Timeout"] = new Variable(MenuComponent.MenuResults.Timeout);
            variableMap["MenuResult.InvalidOption"] = new Variable(MenuComponent.MenuResults.InvalidOption);
            variableMap["MenuResult.ValidOption"] = new Variable(MenuComponent.MenuResults.ValidOption);
            variableMap["UserInputResult.Timeout"] = new Variable(UserInputComponent.UserInputResults.Timeout);
            variableMap["UserInputResult.InvalidDigits"] = new Variable(UserInputComponent.UserInputResults.InvalidDigits);
            variableMap["UserInputResult.ValidDigits"] = new Variable(UserInputComponent.UserInputResults.ValidDigits);

            // User variables
            variableMap["RecordResult.NothingRecorded"] = new Variable(RecordComponent.RecordResults.NothingRecorded);
            variableMap["RecordResult.StopDigit"] = new Variable(RecordComponent.RecordResults.StopDigit);
            variableMap["RecordResult.Completed"] = new Variable(RecordComponent.RecordResults.Completed);
            variableMap["MenuResult.Timeout"] = new Variable(MenuComponent.MenuResults.Timeout);
            variableMap["MenuResult.InvalidOption"] = new Variable(MenuComponent.MenuResults.InvalidOption);
            variableMap["MenuResult.ValidOption"] = new Variable(MenuComponent.MenuResults.ValidOption);
            variableMap["UserInputResult.Timeout"] = new Variable(UserInputComponent.UserInputResults.Timeout);
            variableMap["UserInputResult.InvalidDigits"] = new Variable(UserInputComponent.UserInputResults.InvalidDigits);
            variableMap["UserInputResult.ValidDigits"] = new Variable(UserInputComponent.UserInputResults.ValidDigits);
            
        }

        private void InitializeComponents(ICallflow callflow, ICall myCall, string logHeader)
        {
            {
            MenuComponent MainMenu = new MenuComponent("MainMenu", callflow, myCall, logHeader);
            MainMenu.AllowDtmfInput = true;
            MainMenu.MaxRetryCount = 1;
            MainMenu.Timeout = 10000;
            MainMenu.ValidOptionList.AddRange(new char[] { '1', '2' });
            MainMenu.InitialPrompts.Add(new AudioFilePrompt(() => { return "CFDintro.wav"; }));
            MainMenu.SubsequentPrompts.Add(new AudioFilePrompt(() => { return "CFDintro.wav"; }));
            MainMenu.InvalidDigitPrompts.Add(new AudioFilePrompt(() => { return "CFDinvalidinput.wav"; }));
            MainMenu.TimeoutPrompts.Add(new AudioFilePrompt(() => { return "CFDtimeout.wav"; }));
            mainFlowComponentList.Add(MainMenu);
            ConditionalComponent MainMenu_Conditional = new ConditionalComponent("MainMenu_Conditional", callflow, myCall, logHeader);
            mainFlowComponentList.Add(MainMenu_Conditional);
            MainMenu_Conditional.ConditionList.Add(() => { return MainMenu.Result == MenuComponent.MenuResults.ValidOption && MainMenu.SelectedOption == '1'; });
            MainMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("MainMenu_Conditional_Option1", callflow, myCall, logHeader));
            Support_Option Support_Option = new Support_Option("Support_Option", callflow, myCall, logHeader);
            MainMenu_Conditional.ContainerList[0].ComponentList.Add(Support_Option);
            MainMenu_Conditional.ConditionList.Add(() => { return MainMenu.Result == MenuComponent.MenuResults.ValidOption && MainMenu.SelectedOption == '2'; });
            MainMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("MainMenu_Conditional_Option2", callflow, myCall, logHeader));
            Sales_Option Sales_Option = new Sales_Option("Sales_Option", callflow, myCall, logHeader);
            MainMenu_Conditional.ContainerList[1].ComponentList.Add(Sales_Option);
            MainMenu_Conditional.ConditionList.Add(() => { return MainMenu.Result == MenuComponent.MenuResults.InvalidOption || MainMenu.Result == MenuComponent.MenuResults.Timeout; });
            MainMenu_Conditional.ContainerList.Add(new SequenceContainerComponent("MainMenu_Conditional_TimeoutOrInvalidOption", callflow, myCall, logHeader));
            PromptPlaybackComponent TransferOperator = new PromptPlaybackComponent("TransferOperator", callflow, myCall, logHeader);
            TransferOperator.AllowDtmfInput = true;
            TransferOperator.Prompts.Add(new AudioFilePrompt(() => { return "CFDtransferoperator.wav"; }));
            MainMenu_Conditional.ContainerList[2].ComponentList.Add(TransferOperator);
            TransferComponent TransferToOperator = new TransferComponent("TransferToOperator", callflow, myCall, logHeader);
            TransferToOperator.DestinationHandler = () => { return Convert.ToString(100); };
            TransferToOperator.DelayMilliseconds = 500;
            MainMenu_Conditional.ContainerList[2].ComponentList.Add(TransferToOperator);
            }
            {
            }
            {
            }
            

            // Add a final DisconnectCall component to the main and error handler flows, in order to complete pending prompt playbacks...
            DisconnectCallComponent mainAutoAddedFinalDisconnectCall = new DisconnectCallComponent("mainAutoAddedFinalDisconnectCall", callflow, myCall, logHeader);
            DisconnectCallComponent errorHandlerAutoAddedFinalDisconnectCall = new DisconnectCallComponent("errorHandlerAutoAddedFinalDisconnectCall", callflow, myCall, logHeader);
            mainFlowComponentList.Add(mainAutoAddedFinalDisconnectCall);
            errorFlowComponentList.Add(errorHandlerAutoAddedFinalDisconnectCall);
        }

        private bool IsServerOfficeHourActive(ICall myCall)
        {
            DateTime nowDt = DateTime.Now;
            Tenant tenant = myCall.PS.GetTenant();
            if (tenant == null || tenant.IsHoliday(new DateTimeOffset(nowDt)))
                return false;

            string overrideOfficeTime = tenant.GetPropertyValue("OVERRIDEOFFICETIME");
            if (!String.IsNullOrEmpty(overrideOfficeTime))
            {
                if (overrideOfficeTime == "1") // Forced to in office hours
                    return true;
                else if (overrideOfficeTime == "2") // Forced to out of office hours
                    return false;
            }

            Schedule officeHours = tenant.Hours;
            Nullable<bool> result = officeHours.IsActiveTime(nowDt);
            return result.GetValueOrDefault(false);
        }

        public Main()
        {
            this.executionStarted = false;
            this.executionFinished = false;

            this.eventBuffer = new BufferBlock<AbsEvent>();

            this.currentComponentIndex = 0;
            this.mainFlowComponentList = new List<AbsComponent>();
            this.disconnectFlowComponentList = new List<AbsComponent>();
            this.errorFlowComponentList = new List<AbsComponent>();
            this.currentFlowComponentList = mainFlowComponentList;

            this.timerManager = new TimerManager();
            this.timerManager.OnTimeout += (state) => eventBuffer.Post(new TimeoutEvent(state));
            this.variableMap = new Dictionary<string, Variable>();
        }

        public override void Start()
        {
            MyCall.SetBackgroundAudio(false, new string[] { });

            string callID = MyCall?.Caller["chid"] ?? "Unknown";
            string logHeader = $"CFD_3 - CallID {callID}";
            this.logFormatter = new LogFormatter(MyCall, logHeader, "Callflow");
            this.promptQueue = new PromptQueue(this, MyCall, "CFD_3", logHeader);
            this.tempWavFileManager = new TempWavFileManager(logFormatter);
            this.timerManager.CallStarted();

            InitializeComponents(this, MyCall, logHeader);
            InitializeVariables(callID);
            
            MyCall.OnTerminated += () => eventBuffer.Post(new CallTerminatedEvent());
            MyCall.OnDTMFInput += x => eventBuffer.Post(new DTMFReceivedEvent(x));

            logFormatter.Trace("Start executing main flow...");
            eventBuffer.Post(new StartEvent());
            Task.Run(() => EventProcessingLoop());

            
        }
        
        public void PostStartEvent()
        {
            eventBuffer.Post(new StartEvent());
        }

        public void PostDTMFReceivedEvent(char digit)
        {
            eventBuffer.Post(new DTMFReceivedEvent(digit));
        }

        public void PostPromptPlayedEvent()
        {
            eventBuffer.Post(new PromptPlayedEvent());
        }

        public void PostTransferFailedEvent()
        {
            eventBuffer.Post(new TransferFailedEvent());
        }

        public void PostMakeCallResultEvent(bool result)
        {
            eventBuffer.Post(new MakeCallResultEvent(result));
        }

        public void PostCallTerminatedEvent()
        {
            eventBuffer.Post(new CallTerminatedEvent());
        }

        public void PostTimeoutEvent(object state)
        {
            eventBuffer.Post(new TimeoutEvent(state));
        }

        private async Task EventProcessingLoop()
        {
            executionStarted = true;
            while (!executionFinished)
            {
                AbsEvent evt = await eventBuffer.ReceiveAsync();
                await evt?.ProcessEvent(this);
            }
        }
        
        public async Task ProcessStart()
        {
            try
            {
                EventResults eventResult;
                do
                {
                    AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                    logFormatter.Trace("Start executing component '" + currentComponent.Name + "'");
                    eventResult = await currentComponent.Start(timerManager, variableMap, tempWavFileManager, promptQueue);
                }
                while (CheckEventResult(eventResult) == EventResults.MoveToNextComponent);
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessDTMFReceived(char digit)
        {
            try
            {
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnDTMFReceived for component '" + currentComponent.Name + "' - Digit: '" + digit + "'");
                EventResults eventResult = await currentComponent.OnDTMFReceived(timerManager, variableMap, tempWavFileManager, promptQueue, digit);
                if (CheckEventResult(eventResult) == EventResults.MoveToNextComponent)
                    await ProcessStart();
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessPromptPlayed()
        {
            try
            {
                promptQueue.NotifyPlayFinished();
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnPromptPlayed for component '" + currentComponent.Name + "'");
                EventResults eventResult = await currentComponent.OnPromptPlayed(timerManager, variableMap, tempWavFileManager, promptQueue);
                if (CheckEventResult(eventResult) == EventResults.MoveToNextComponent)
                    await ProcessStart();
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessTransferFailed()
        {
            try
            {
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnTransferFailed for component '" + currentComponent.Name + "'");
                EventResults eventResult = await currentComponent.OnTransferFailed(timerManager, variableMap, tempWavFileManager, promptQueue);
                if (CheckEventResult(eventResult) == EventResults.MoveToNextComponent)
                    await ProcessStart();
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessMakeCallResult(bool result)
        {
            try
            {
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnMakeCallResult for component '" + currentComponent.Name + "' - Result: '" + result + "'");
                EventResults eventResult = await currentComponent.OnMakeCallResult(timerManager, variableMap, tempWavFileManager, promptQueue, result);
                if (CheckEventResult(eventResult) == EventResults.MoveToNextComponent)
                    await ProcessStart();
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessCallTerminated()
        {
            try
            {
                if (executionStarted)
                {
                    // First notify the current component
                    AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                    logFormatter.Trace("OnCallTerminated for component '" + currentComponent.Name + "'");
                    await currentComponent.OnCallTerminated(timerManager, variableMap, tempWavFileManager, promptQueue);

                    // Next, execute disconnect flow
                    currentFlowComponentList = disconnectFlowComponentList;
                    logFormatter.Trace("Start executing disconnect handler flow...");
                    foreach (AbsComponent component in disconnectFlowComponentList)
                    {
                        logFormatter.Trace("Start executing component '" + component.Name + "'");
                        await component.Start(timerManager, variableMap, tempWavFileManager, promptQueue);
                    }
                }
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
            finally
            {
                // Finally, delete temporary files
                tempWavFileManager.DeleteFilesAndFolders();
                executionFinished = true;
            }
        }

        public async Task ProcessTimeout(object state)
        {
            try
            {
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnTimeout for component '" + currentComponent.Name + "'");
                EventResults eventResult = await currentComponent.OnTimeout(timerManager, variableMap, tempWavFileManager, promptQueue, state);
                if (CheckEventResult(eventResult) == EventResults.MoveToNextComponent)
                    await ProcessStart();
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }


        public class TcxSetExtensionStatusTempComponent : AbsComponent
        {
            private StringExpressionHandler extensionHandler = null;
            private StringExpressionHandler profileNameHandler = null;

            public TcxSetExtensionStatusTempComponent(string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
            }

            public string Extension { get; set; } = string.Empty;
            public string ProfileName { get; set; } = string.Empty;

            public StringExpressionHandler ExtensionHandler
            {
                set { extensionHandler = value; }
            }

            public StringExpressionHandler ProfileNameHandler
            {
                set { profileNameHandler = value; }
            }

            private EventResults ExecuteStart()
            {
                if (extensionHandler != null) Extension = extensionHandler();
                if (profileNameHandler != null) ProfileName = profileNameHandler();

                using (DN dn = myCall.PS.GetDNByNumber(Extension))
                {
                    if (!(dn is Extension ext)) throw new Exception("Extension '" + Extension + "' could not be found.");

                    logFormatter.Trace("Setting status for Extension='" + Extension + "' to '" + ProfileName + "'");

                    // Activate the selected profile
                    bool profileFound = false;
                    foreach (FwdProfile profile in ext.FwdProfiles)
                    {
                        if (profile.Name == ProfileName)
                        {
                            ext.CurrentProfile = profile;
                            profileFound = true;
                            break;
                        }
                    }

                    if (profileFound)
                    {
                        // And disable override if active
                        if (ext.IsOverrideActiveNow) ext.OverrideExpiresAt = DateTime.UtcNow;
                        logFormatter.Trace("Status for Extension='" + Extension + "' updated.");
                        ext.Save();
                    }
                    else
                        logFormatter.Trace("Status for Extension='" + Extension + "' could not be updated, profile name not found.");
                }
                return EventResults.MoveToNextComponent;
            }

            public override Task<EventResults> Start(Dictionary<string, Variable> variableMap)
            {
                return Task.FromResult(ExecuteStart());
            }

            public override Task<EventResults> Start(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue)
            {
                return Task.FromResult(ExecuteStart());
            }

            public override Task<EventResults> OnDTMFReceived(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue, char digit)
            {
                return IgnoreDTMFReceivedEventWithResult(digit, EventResults.MoveToNextComponent);
            }

            public override Task<EventResults> OnPromptPlayed(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue)
            {
                return IgnoreEventWithResult("OnPromptPlayed", EventResults.MoveToNextComponent);
            }

            public override Task<EventResults> OnTransferFailed(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue)
            {
                return IgnoreEventWithResult("OnTransferFailed", EventResults.MoveToNextComponent);
            }

            public override Task<EventResults> OnMakeCallResult(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue, bool result)
            {
                return IgnoreMakeCallResult(result, EventResults.MoveToNextComponent);
            }

            public override Task<EventResults> OnCallTerminated(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue)
            {
                return ProcessEventWithResult("OnCallTerminated", EventResults.MoveToNextComponent);
            }

            public override Task<EventResults> OnTimeout(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue, object state)
            {
                return IgnoreEventWithResult("OnTimeout", EventResults.MoveToNextComponent);
            }
        }

        public class MySqlDatabaseAccessTempComponent : DatabaseAccessTempComponent
        {
            protected override DbConnection CreateConnection()
            {
                return new MySqlConnection(useConnectionString ? connectionString : string.Format("Server={0};Port={1};Database={2};User Id={3};Password={4}", server, port == -1 ? 3306 : port, database, userName, password));
            }

            public MySqlDatabaseAccessTempComponent(string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
            }
        }

        public class PostgresqlDatabaseAccessTempComponent : DatabaseAccessTempComponent
        {
            protected override DbConnection CreateConnection()
            {
                return new NpgsqlConnection(useConnectionString ? connectionString : string.Format("Server={0};Port={1};Database={2};User Id={3};Password={4}", server, port == -1 ? 5432 : port, database, userName, password));
            }

            public PostgresqlDatabaseAccessTempComponent(string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
            }
        }

        public class SqlServerDatabaseAccessTempComponent : DatabaseAccessTempComponent
        {
            protected override DbConnection CreateConnection()
            {
                return new SqlConnection(useConnectionString ? connectionString : string.Format("Data Source=tcp:{0}{1};initial catalog={2};user id={3};password={4};Pooling=true", server, port == -1 ? string.Empty : "," + port, database, userName, password));
            }

            public SqlServerDatabaseAccessTempComponent(string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
            }
        }

        public abstract class DatabaseAccessTempComponent : AbsComponent
        {
            public enum StatementTypes
            {
                Query,
                NonQuery,
                Scalar
            }

            protected bool useConnectionString = false;
            protected string connectionString = string.Empty;
            protected string server = string.Empty;
            protected int port = -1;
            protected string database = string.Empty;
            protected string userName = string.Empty;
            protected string password = string.Empty;
            private string sqlStatement = string.Empty;

            private StringExpressionHandler connectionStringHandler = null;
            private StringExpressionHandler serverHandler = null;
            private IntegerExpressionHandler portHandler = null;
            private StringExpressionHandler databaseHandler = null;
            private StringExpressionHandler userNameHandler = null;
            private StringExpressionHandler passwordHandler = null;
            private StringExpressionHandler sqlStatementHandler = null;

            protected abstract DbConnection CreateConnection();

            private async Task ExecuteStatement(DbConnection conn)
            {
                if (StatementType == StatementTypes.Query)
                {
                    using (DbDataReader reader = await ExecuteReaderAsync(conn))
                    {
                        while (await reader.ReadAsync())
                        {
                            object[] recordValues = new object[reader.FieldCount];
                            reader.GetValues(recordValues);
                            QueryResult.Add(recordValues);
                        }
                    }
                }
                else if (StatementType == StatementTypes.NonQuery)
                    NonQueryResult = await ExecuteNonQueryAsync(conn);
                else
                    ScalarResult = await ExecuteScalarAsync(conn);
            }

            private async Task<DbCommand> PrepareCommandAsync(DbConnection conn)
            {
                logFormatter.Trace("Command to execute: " + sqlStatement);

                await conn.OpenAsync();
                DbCommand cmd = conn.CreateCommand();
                cmd.CommandText = sqlStatement;
                cmd.CommandTimeout = Timeout;
                cmd.CommandType = CommandType.Text;
                return cmd;
            }

            private async Task<DbDataReader> ExecuteReaderAsync(DbConnection conn)
            {
                DbCommand cmd = await PrepareCommandAsync(conn);
                return await cmd.ExecuteReaderAsync();
            }

            private async Task<int> ExecuteNonQueryAsync(DbConnection conn)
            {
                DbCommand cmd = await PrepareCommandAsync(conn);
                return await cmd.ExecuteNonQueryAsync();
            }

            private async Task<object> ExecuteScalarAsync(DbConnection conn)
            {
                DbCommand cmd = await PrepareCommandAsync(conn);
                return await cmd.ExecuteScalarAsync();
            }

            public DatabaseAccessTempComponent(string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
            }

            public bool UseConnectionString
            {
                get { return useConnectionString; }
                set { useConnectionString = value; }
            }

            public string ConnectionString
            {
                get { return connectionString; }
                set { connectionString = value; }
            }

            public string Server
            {
                get { return server; }
                set { server = value; }
            }

            public int Port
            {
                get { return port; }
                set { port = value; }
            }

            public string Database
            {
                get { return database; }
                set { database = value; }
            }

            public string UserName
            {
                get { return userName; }
                set { userName = value; }
            }

            public string Password
            {
                get { return password; }
                set { password = value; }
            }

            public string SqlStatement
            {
                get { return sqlStatement; }
                set { sqlStatement = value; }
            }

            public StatementTypes StatementType { get; set; } = StatementTypes.Query;
            public int Timeout { get; set; } = 30000;

            public StringExpressionHandler ConnectionStringHandler
            {
                set { connectionStringHandler = value; }
            }

            public StringExpressionHandler ServerHandler
            {
                set { serverHandler = value; }
            }

            public IntegerExpressionHandler PortHandler
            {
                set { portHandler = value; }
            }

            public StringExpressionHandler DatabaseHandler
            {
                set { databaseHandler = value; }
            }

            public StringExpressionHandler UserNameHandler
            {
                set { userNameHandler = value; }
            }

            public StringExpressionHandler PasswordHandler
            {
                set { passwordHandler = value; }
            }

            public StringExpressionHandler SqlStatementHandler
            {
                set { sqlStatementHandler = value; }
            }

            public object ScalarResult { get; private set; } = null;
            public int NonQueryResult { get; private set; } = 0;
            public List<object[]> QueryResult { get; private set; } = new List<object[]>();

            private async Task<EventResults> ExecuteStart()
            {
                ScalarResult = null;
                NonQueryResult = 0;
                QueryResult = new List<object[]>();

                if (useConnectionString)
                {
                    if (connectionStringHandler != null) connectionString = connectionStringHandler();
                    logFormatter.Trace("Start executing component with connectionString='" + connectionString + "'");
                }
                else
                {
                    if (serverHandler != null) server = serverHandler();
                    if (portHandler != null) port = portHandler();
                    if (databaseHandler != null) database = databaseHandler();
                    if (userNameHandler != null) userName = userNameHandler();
                    if (passwordHandler != null) password = passwordHandler();

                    logFormatter.Trace("Start executing component with server='" + server + "' - port='" + port + "' - database='" + database + "' - statementType='" + StatementType + "'");
                }

                if (sqlStatementHandler != null) sqlStatement = sqlStatementHandler();

                using (DbConnection conn = CreateConnection())
                {
                    await ExecuteStatement(conn);
                }

                if (StatementType == StatementTypes.Query)
                {
                    StringBuilder sb = new StringBuilder();
                    foreach (object[] record in QueryResult)
                    {
                        sb.Append("[");
                        sb.Append(string.Join<object>(",", record));
                        sb.Append("]").AppendLine();
                    }
                    logFormatter.Trace("End executing component with queryResult: " + sb.ToString());
                }
                else if (StatementType == StatementTypes.Scalar)
                    logFormatter.Trace("End executing component with scalarResult: " + ScalarResult);
                else
                    logFormatter.Trace("End executing component with nonQueryResult: " + NonQueryResult);

                return EventResults.MoveToNextComponent;
            }

            public override async Task<EventResults> Start(Dictionary<string, Variable> variableMap)
            {
                return await ExecuteStart();
            }

            public override async Task<EventResults> Start(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue)
            {
                return await ExecuteStart();
            }

            public override Task<EventResults> OnDTMFReceived(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue, char digit)
            {
                return IgnoreDTMFReceivedEventWithResult(digit, EventResults.MoveToNextComponent);
            }

            public override Task<EventResults> OnPromptPlayed(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue)
            {
                return IgnoreEventWithResult("OnPromptPlayed", EventResults.MoveToNextComponent);
            }

            public override Task<EventResults> OnTransferFailed(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue)
            {
                return IgnoreEventWithResult("OnTransferFailed", EventResults.MoveToNextComponent);
            }

            public override Task<EventResults> OnMakeCallResult(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue, bool result)
            {
                return IgnoreMakeCallResult(result, EventResults.MoveToNextComponent);
            }

            public override Task<EventResults> OnCallTerminated(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue)
            {
                return ProcessEventWithResult("OnCallTerminated", EventResults.MoveToNextComponent);
            }

            public override Task<EventResults> OnTimeout(TimerManager timerManager, Dictionary<string, Variable> variableMap, TempWavFileManager tempWavFileManager, PromptQueue promptQueue, object state)
            {
                return IgnoreEventWithResult("OnTimeout", EventResults.MoveToNextComponent);
            }
        }

                // ------------------------------------------------------------------------------------------------------------
        // User Defined component
        // ------------------------------------------------------------------------------------------------------------
        public class Sales_Option : AbsUserComponent
        {
            

            protected override void InitializeVariables()
            {
                
            }

            protected override void InitializeComponents()
            {
                Dictionary<string, Variable> variableMap = componentVariableMap;
                {
            ConditionalComponent SalesOfficeHours = new ConditionalComponent("SalesOfficeHours", callflow, myCall, logHeader);
            mainFlowComponentList.Add(SalesOfficeHours);
            SalesOfficeHours.ConditionList.Add(() => { return Convert.ToBoolean(((DateTime.Now.DayOfWeek == DayOfWeek.Monday || DateTime.Now.DayOfWeek == DayOfWeek.Tuesday || DateTime.Now.DayOfWeek == DayOfWeek.Wednesday || DateTime.Now.DayOfWeek == DayOfWeek.Thursday) && (DateTime.Now.Hour > 9 || DateTime.Now.Hour == 9 && DateTime.Now.Minute >= 0) && (DateTime.Now.Hour < 17 || DateTime.Now.Hour == 17 && DateTime.Now.Minute <= 0))); });
            SalesOfficeHours.ContainerList.Add(new SequenceContainerComponent("SalesOfficeHours_0", callflow, myCall, logHeader));
            PromptPlaybackComponent TransferSales = new PromptPlaybackComponent("TransferSales", callflow, myCall, logHeader);
            TransferSales.AllowDtmfInput = true;
            TransferSales.Prompts.Add(new AudioFilePrompt(() => { return "CFDtransfersales.wav"; }));
            SalesOfficeHours.ContainerList[0].ComponentList.Add(TransferSales);
            TransferComponent TransferToSales = new TransferComponent("TransferToSales", callflow, myCall, logHeader);
            TransferToSales.DestinationHandler = () => { return Convert.ToString(800); };
            TransferToSales.DelayMilliseconds = 500;
            SalesOfficeHours.ContainerList[0].ComponentList.Add(TransferToSales);
            SalesOfficeHours.ConditionList.Add(() => { return Convert.ToBoolean(((DateTime.Now.DayOfWeek == DayOfWeek.Sunday || DateTime.Now.DayOfWeek == DayOfWeek.Friday || DateTime.Now.DayOfWeek == DayOfWeek.Saturday) && (DateTime.Now.Hour > 0 || DateTime.Now.Hour == 0 && DateTime.Now.Minute >= 0) && (DateTime.Now.Hour < 23 || DateTime.Now.Hour == 23 && DateTime.Now.Minute <= 59))); });
            SalesOfficeHours.ContainerList.Add(new SequenceContainerComponent("SalesOfficeHours_1", callflow, myCall, logHeader));
            RecordAndEmailComponent RecordAndEmail = new RecordAndEmailComponent("RecordAndEmail", callflow, myCall, logHeader);
            RecordAndEmail.Beep = true;
            RecordAndEmail.MaxTime = 60000;
            RecordAndEmail.TerminateByDtmf = true;
            RecordAndEmail.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, "AmazonPollyClientIDHere", "AmazonPollyClientSecretHere", "us-east-2", "Joanna", TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Our Sales Team is currently offline. Please leave a message after the tone, and then press any button"); }));
            RecordAndEmail.UseServerSettings = true;
            RecordAndEmail.ToHandler = () => { return Convert.ToString("email@example.com"); };
            RecordAndEmail.SubjectHandler = () => { return Convert.ToString("After Hours Voice Message - Sales Queue"); };
            RecordAndEmail.BodyHandler = () => { return Convert.ToString("A voice message has been left by a caller after hours. Please action on this ASAP"); };
            RecordAndEmail.IsBodyHtml = false;
            RecordAndEmail.Priority = MessagePriority.Normal;
            SalesOfficeHours.ContainerList[1].ComponentList.Add(RecordAndEmail);
            PromptPlaybackComponent MessageVerification = new PromptPlaybackComponent("MessageVerification", callflow, myCall, logHeader);
            MessageVerification.AllowDtmfInput = true;
            MessageVerification.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, "AmazonPollyClientIDHere", "AmazonPollyClientSecretHere", "us-east-2", "Joanna", TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Your message has been received. Thank you"); }));
            SalesOfficeHours.ContainerList[1].ComponentList.Add(MessageVerification);
            DisconnectCallComponent DisconnectCall = new DisconnectCallComponent("DisconnectCall", callflow, myCall, logHeader);
            SalesOfficeHours.ContainerList[1].ComponentList.Add(DisconnectCall);
            }
            {
            }
            {
            }
            
            }
            
            public Sales_Option(string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
            }

            protected override void GetVariableValues()
            {
                
            }
            
            

            private bool IsServerOfficeHourActive(ICall myCall)
            {
                DateTime nowDt = DateTime.Now;
                Tenant tenant = myCall.PS.GetTenant();
                if (tenant == null || tenant.IsHoliday(new DateTimeOffset(nowDt)))
                    return false;

                string overrideOfficeTime = tenant.GetPropertyValue("OVERRIDEOFFICETIME");
                if (!String.IsNullOrEmpty(overrideOfficeTime))
                {
                    if (overrideOfficeTime == "1") // Forced to in office hours
                        return true;
                    else if (overrideOfficeTime == "2") // Forced to out of office hours
                        return false;
                }

                Schedule officeHours = tenant.Hours;
                Nullable<bool> result = officeHours.IsActiveTime(nowDt);
                return result.GetValueOrDefault(false);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        // User Defined component
        // ------------------------------------------------------------------------------------------------------------
        public class Support_Option : AbsUserComponent
        {
            

            protected override void InitializeVariables()
            {
                
            }

            protected override void InitializeComponents()
            {
                Dictionary<string, Variable> variableMap = componentVariableMap;
                {
            AuthenticationLoopComponent Authentication = new AuthenticationLoopComponent("Authentication", callflow, myCall, logHeader);
            Authentication.Condition = () => { return Convert.ToBoolean(CFDFunctions.AND(Convert.ToBoolean(CFDFunctions.LESS_THAN((IComparable)Authentication.LoopCounter,(IComparable)4)),Convert.ToBoolean(CFDFunctions.NOT(Convert.ToBoolean(variableMap["Authentication.Validated"].Value))))); };
            Authentication.Container = new SequenceContainerComponent("Authentication_Container", callflow, myCall, logHeader);
            mainFlowComponentList.Add(Authentication);
            UserInputComponent AuthenticationRequestId = new UserInputComponent("AuthenticationRequestId", callflow, myCall, logHeader);
            AuthenticationRequestId.AllowDtmfInput = true;
            AuthenticationRequestId.MaxRetryCount = 2;
            AuthenticationRequestId.FirstDigitTimeout = 5000;
            AuthenticationRequestId.InterDigitTimeout = 3000;
            AuthenticationRequestId.FinalDigitTimeout = 2000;
            AuthenticationRequestId.MinDigits = 4;
            AuthenticationRequestId.MaxDigits = 4;
            AuthenticationRequestId.ValidDigitList.AddRange(new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' });
            AuthenticationRequestId.InitialPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, "AmazonPollyClientIDHere", "AmazonPollyClientSecretHere", "us-east-2", "Joanna", TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Please enter your 4 digit Support ID"); }));
            AuthenticationRequestId.SubsequentPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, "AmazonPollyClientIDHere", "AmazonPollyClientSecretHere", "us-east-2", "Joanna", TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("Please enter your 4 digit Support ID"); }));
            AuthenticationRequestId.InvalidDigitPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, "AmazonPollyClientIDHere", "AmazonPollyClientSecretHere", "us-east-2", "Joanna", TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("You have entered an invalid Support ID"); }));
            AuthenticationRequestId.TimeoutPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, "AmazonPollyClientIDHere", "AmazonPollyClientSecretHere", "us-east-2", "Joanna", TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("A support ID has not been entered"); }));
            Authentication.Container.ComponentList.Add(AuthenticationRequestId);
            Authentication.IdHandler = () => { return AuthenticationRequestId.Buffer; };
            ConditionalComponent AuthenticationRequestId_Conditional = new ConditionalComponent("AuthenticationRequestId_Conditional", callflow, myCall, logHeader);
            Authentication.Container.ComponentList.Add(AuthenticationRequestId_Conditional);
            AuthenticationRequestId_Conditional.ConditionList.Add(() => { return AuthenticationRequestId.Result == UserInputComponent.UserInputResults.ValidDigits; });
            AuthenticationRequestId_Conditional.ContainerList.Add(new SequenceContainerComponent("AuthenticationRequestId_Conditional_ValidInput", callflow, myCall, logHeader));
            PromptPlaybackComponent ID_Verification = new PromptPlaybackComponent("ID_Verification", callflow, myCall, logHeader);
            ID_Verification.AllowDtmfInput = true;
            ID_Verification.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, "AmazonPollyClientIDHere", "AmazonPollyClientSecretHere", "us-east-2", "Joanna", TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("The Support ID you have entered is"); }));
            ID_Verification.Prompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, "AmazonPollyClientIDHere", "AmazonPollyClientSecretHere", "us-east-2", "Joanna", TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString(Authentication.ID); }));
            AuthenticationRequestId_Conditional.ContainerList[0].ComponentList.Add(ID_Verification);
            PromptPlaybackComponent TransferSupport = new PromptPlaybackComponent("TransferSupport", callflow, myCall, logHeader);
            TransferSupport.AllowDtmfInput = true;
            TransferSupport.Prompts.Add(new AudioFilePrompt(() => { return "CFDtransfersupport.wav"; }));
            AuthenticationRequestId_Conditional.ContainerList[0].ComponentList.Add(TransferSupport);
            TransferComponent TransferToSupport = new TransferComponent("TransferToSupport", callflow, myCall, logHeader);
            TransferToSupport.DestinationHandler = () => { return Convert.ToString(800); };
            TransferToSupport.DelayMilliseconds = 500;
            AuthenticationRequestId_Conditional.ContainerList[0].ComponentList.Add(TransferToSupport);
            ConditionalComponent Authentication_InvalidInputConditional = new ConditionalComponent("Authentication_InvalidInputConditional", callflow, myCall, logHeader);
            Authentication.Container.ComponentList.Add(Authentication_InvalidInputConditional);
            Authentication_InvalidInputConditional.ConditionList.Add(() => { return AuthenticationRequestId.Result == UserInputComponent.UserInputResults.InvalidDigits || AuthenticationRequestId.Result == UserInputComponent.UserInputResults.Timeout; });
            Authentication_InvalidInputConditional.ContainerList.Add(new SequenceContainerComponent("Authentication_InvalidInputConditional", callflow, myCall, logHeader));
            Sales_Option Sales_Option = new Sales_Option("Sales_Option", callflow, myCall, logHeader);
            Authentication_InvalidInputConditional.ContainerList[0].ComponentList.Add(Sales_Option);
            }
            {
            }
            {
            }
            
            }
            
            public Support_Option(string name, ICallflow callflow, ICall myCall, string logHeader) : base(name, callflow, myCall, logHeader)
            {
            }

            protected override void GetVariableValues()
            {
                
            }
            
            

            private bool IsServerOfficeHourActive(ICall myCall)
            {
                DateTime nowDt = DateTime.Now;
                Tenant tenant = myCall.PS.GetTenant();
                if (tenant == null || tenant.IsHoliday(new DateTimeOffset(nowDt)))
                    return false;

                string overrideOfficeTime = tenant.GetPropertyValue("OVERRIDEOFFICETIME");
                if (!String.IsNullOrEmpty(overrideOfficeTime))
                {
                    if (overrideOfficeTime == "1") // Forced to in office hours
                        return true;
                    else if (overrideOfficeTime == "2") // Forced to out of office hours
                        return false;
                }

                Schedule officeHours = tenant.Hours;
                Nullable<bool> result = officeHours.IsActiveTime(nowDt);
                return result.GetValueOrDefault(false);
            }
        }

    }
}
